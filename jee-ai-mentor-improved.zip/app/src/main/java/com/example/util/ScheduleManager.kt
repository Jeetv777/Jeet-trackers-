package com.example.util

import com.example.data.ScheduleLog
import java.util.*

data class ScheduleSlot(
    val id: String,
    val name: String,
    val startTimeStr: String, // "06:00", "13:30", etc.
    val endTimeStr: String,   // "07:30", "14:00", etc.
    val isStudySlot: Boolean, // Requires check-in
    val startMin: Int,        // Minutes since midnight
    val endMin: Int           // Minutes since midnight
) {
    fun isCurrent(currentMin: Int): Boolean {
        return if (startMin <= endMin) {
            currentMin in startMin until endMin
        } else {
            // Over midnight slot (e.g., 20:30 to 06:00)
            currentMin >= startMin || currentMin < endMin
        }
    }

    fun minutesRemaining(currentMin: Int): Int {
        val remaining = if (startMin <= endMin) {
            endMin - currentMin
        } else {
            if (currentMin >= startMin) {
                (24 * 60 - currentMin) + endMin
            } else {
                endMin - currentMin
            }
        }
        return remaining.coerceAtLeast(0)
    }

    fun getFormattedStart(): String {
        return ScheduleManager.formatTimeStr(startTimeStr)
    }

    fun getFormattedEnd(): String {
        return ScheduleManager.formatTimeStr(endTimeStr)
    }
}

object ScheduleManager {

    /**
     * Parse "HH:MM" format to minutes since midnight
     */
    private fun parseTimeToMin(timeStr: String): Int {
        val parts = timeStr.split(":")
        val hrs = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val mins = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return hrs * 60 + mins
    }

    private fun createSlot(id: String, name: String, start: String, end: String, isStudy: Boolean): ScheduleSlot {
        return ScheduleSlot(
            id = id,
            name = name,
            startTimeStr = start,
            endTimeStr = end,
            isStudySlot = isStudy,
            startMin = parseTimeToMin(start),
            endMin = parseTimeToMin(end)
        )
    }

    /**
     * Get the schedule slots for a given day and Sunday case
     */
    fun getSlotsForDay(dayOfWeek: Int, sundayCase: Int): List<ScheduleSlot> {
        return when (dayOfWeek) {
            Calendar.SATURDAY -> listOf(
                createSlot("sat_morning", "Morning Session (Study)", "06:00", "08:00", true),
                createSlot("sat_breakfast", "Breakfast & Shower/Prep", "08:00", "08:30", false),
                createSlot("sat_flexible", "The Flexible Slot (Study/School)", "08:30", "11:00", true),
                createSlot("sat_school_study", "School / Study Slot", "11:00", "13:30", true),
                createSlot("sat_lunch", "Lunch Break & Quick Reset", "13:30", "14:00", false),
                createSlot("sat_afternoon", "Afternoon Session (Study)", "14:00", "16:30", true),
                createSlot("sat_chill", "My Time (Phone + TV)", "16:30", "17:30", false),
                createSlot("sat_final", "Final Session (Study)", "17:30", "20:30", true),
                createSlot("sat_night", "Done for the Day! Dinner, relax, sleep", "20:30", "06:00", false)
            )
            Calendar.SUNDAY -> when (sundayCase) {
                1 -> listOf( // Single Exam
                    createSlot("sun1_morning", "Morning Session (Study)", "06:00", "08:00", true),
                    createSlot("sun1_prep", "Get ready, breakfast, prep", "08:00", "08:30", false),
                    createSlot("sun1_exam", "JEE Exam (Lock-in)", "08:30", "12:30", true),
                    createSlot("sun1_lunch", "Lunch & Reset", "12:30", "13:30", false),
                    createSlot("sun1_review", "Light Review / Planning", "13:30", "14:00", true),
                    createSlot("sun1_me", "Me Time (Chill)", "14:00", "15:00", false),
                    createSlot("sun1_evening", "Evening Session (Study/Analysis)", "15:00", "20:30", true),
                    createSlot("sun1_night", "Relax & sleep", "20:30", "06:00", false)
                )
                2 -> listOf( // Double Exam
                    createSlot("sun2_morning", "Morning Session (Study Revision)", "06:00", "08:00", true),
                    createSlot("sun2_prep", "Get ready, eat, head out", "08:00", "08:30", false),
                    createSlot("sun2_exam1", "JEE Exam Paper 1 (Lock-in)", "08:30", "12:30", true),
                    createSlot("sun2_lunch", "Quick Lunch & Transition", "12:30", "13:30", false),
                    createSlot("sun2_exam2", "JEE Exam Paper 2 (Lock-in)", "13:30", "17:30", true),
                    createSlot("sun2_me", "Me Time (Chill & Recharge)", "17:30", "18:30", false),
                    createSlot("sun2_evening", "Evening Session (Error Review)", "18:30", "21:30", true),
                    createSlot("sun2_night", "Relax & sleep", "21:30", "06:00", false)
                )
                else -> listOf( // Full Study Day
                    createSlot("sun3_sleep", "Sleep / Rest", "21:00", "08:00", false),
                    createSlot("sun3_prep", "Wake up & Freshen up", "08:00", "08:30", false),
                    createSlot("sun3_morning", "Morning Session (Long Study Block)", "08:30", "13:30", true),
                    createSlot("sun3_lunch", "Lunch Break", "13:30", "14:00", false),
                    createSlot("sun3_me", "Me Time (Chill)", "14:00", "15:00", false),
                    createSlot("sun3_afternoon", "Afternoon Session (Problem Solving)", "15:00", "18:00", true),
                    createSlot("sun3_evening", "Evening Session (Final Push & Rev)", "18:00", "21:00", true)
                )
            }
            else -> listOf( // Monday to Friday
                createSlot("mf_morning", "Morning Session (Study)", "06:00", "07:30", true),
                createSlot("mf_prep", "Get ready & head out", "07:30", "08:00", false),
                createSlot("mf_allen", "Classes at Allen (Locked In)", "08:00", "13:30", true),
                createSlot("mf_lunch", "Get home, eat lunch & settle in", "13:30", "14:00", false),
                createSlot("mf_afternoon", "Afternoon Session (Lecture Review)", "14:00", "16:45", true),
                createSlot("mf_chill", "Chill Time (Phone + TV)", "16:45", "17:45", false),
                createSlot("mf_evening", "Evening Session (Module Practice)", "17:45", "19:30", true),
                createSlot("mf_final", "Final Session (Review & Plan)", "19:30", "20:30", true),
                createSlot("mf_night", "Done for the Day! Dinner, pack, sleep", "20:30", "06:00", false)
            )
        }
    }

    /**
     * Get current time details specifically in Indian Standard Time (GMT+5:30)
     */
    fun getIndiaDateTime(): Calendar {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        return calendar
    }

    fun getIndiaDateString(calendar: Calendar = getIndiaDateTime()): String {
        val yr = calendar.get(Calendar.YEAR)
        val mo = calendar.get(Calendar.MONTH) + 1
        val dy = calendar.get(Calendar.DAY_OF_MONTH)
        return String.format("%04d-%02d-%02d", yr, mo, dy)
    }

    /**
     * Returns:
     * - "dayName": e.g., "Monday"
     * - "currentTime": e.g., "14:45"
     * - "activeSlot": ScheduleSlot
     * - "minutesRemaining": Int
     * - "isOutOfSchedule": Boolean (if active study slot has started > 5 mins ago, and no check-in is logged)
     */
    fun getCurrentStatus(sundayCase: Int, checkedInSlots: Set<String>): CurrentScheduleStatus {
        val indiaTime = getIndiaDateTime()
        val dayOfWeek = indiaTime.get(Calendar.DAY_OF_WEEK)
        val hrs = indiaTime.get(Calendar.HOUR_OF_DAY)
        val mins = indiaTime.get(Calendar.MINUTE)
        val secs = indiaTime.get(Calendar.SECOND)
        val currentMin = hrs * 60 + mins

        val slots = getSlotsForDay(dayOfWeek, sundayCase)
        val activeSlot = slots.find { it.isCurrent(currentMin) } 
            ?: slots.lastOrNull() // fallback
            ?: createSlot("sleep", "Night Sleep", "21:00", "06:00", false)

        val minsLeft = activeSlot.minutesRemaining(currentMin)

        val dayName = when (dayOfWeek) {
            Calendar.MONDAY -> "Monday"
            Calendar.TUESDAY -> "Tuesday"
            Calendar.WEDNESDAY -> "Wednesday"
            Calendar.THURSDAY -> "Thursday"
            Calendar.FRIDAY -> "Friday"
            Calendar.SATURDAY -> "Saturday"
            Calendar.SUNDAY -> "Sunday"
            else -> "Day"
        }

        // Check if out of schedule:
        // Current slot is study slot, AND has not checked in
        var isOutOfSchedule = false
        var graceRemainingMins = 0
        if (activeSlot.isStudySlot && !checkedInSlots.contains(activeSlot.id)) {
            val minsSinceStart = if (currentMin >= activeSlot.startMin) {
                currentMin - activeSlot.startMin
            } else {
                (24 * 60 - activeSlot.startMin) + currentMin
            }
            if (minsSinceStart > 5) {
                isOutOfSchedule = true
            } else {
                graceRemainingMins = 5 - minsSinceStart
            }
        }

        return CurrentScheduleStatus(
            dayName = dayName,
            timeStr = formatTimeStrWithoutSeconds(hrs, mins),
            activeSlot = activeSlot,
            minutesRemaining = minsLeft,
            isOutOfSchedule = isOutOfSchedule,
            graceMinsRemaining = graceRemainingMins,
            dayOfWeek = dayOfWeek
        )
    }

    fun formatTimeStrWithoutSeconds(hrs: Int, mins: Int): String {
        val suffix = if (hrs >= 12) "PM" else "AM"
        val displayHrs = when {
            hrs == 0 -> 12
            hrs > 12 -> hrs - 12
            else -> hrs
        }
        return String.format("%02d:%02d %s", displayHrs, mins, suffix)
    }

    fun formatTimeStr(timeStr: String): String {
        val parts = timeStr.split(":")
        val hrs = parts.getOrNull(0)?.toIntOrNull() ?: return timeStr
        val mins = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val suffix = if (hrs >= 12) "PM" else "AM"
        val displayHrs = when {
            hrs == 0 -> 12
            hrs > 12 -> hrs - 12
            else -> hrs
        }
        return String.format("%02d:%02d %s", displayHrs, mins, suffix)
    }

    fun getDailyProgressReport(dayOfWeek: Int, sundayCase: Int, checkedInSlots: Set<String>): DailyProgressReport {
        val slots = getSlotsForDay(dayOfWeek, sundayCase)
        var totalPlanned = 0.0
        var totalActual = 0.0
        
        var physicsPlanned = 0.0
        var physicsActual = 0.0
        var chemistryPlanned = 0.0
        var chemistryActual = 0.0
        var mathPlanned = 0.0
        var mathActual = 0.0
        var revPlanned = 0.0
        var revActual = 0.0

        for (slot in slots) {
            if (!slot.isStudySlot) continue
            
            val startMin = slot.startMin
            val endMin = slot.endMin
            val durationMin = if (startMin <= endMin) {
                endMin - startMin
            } else {
                (24 * 60 - startMin) + endMin
            }
            val hours = durationMin.toDouble() / 60.0
            totalPlanned += hours

            val isChecked = checkedInSlots.contains(slot.id)
            if (isChecked) {
                totalActual += hours
            }

            when (slot.id) {
                "mf_morning" -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
                "mf_allen" -> {
                    val split = hours / 3.0
                    physicsPlanned += split
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        physicsActual += split
                        chemistryActual += split
                        mathActual += split
                    }
                }
                "mf_afternoon" -> {
                    chemistryPlanned += hours
                    if (isChecked) chemistryActual += hours
                }
                "mf_evening" -> {
                    mathPlanned += hours
                    if (isChecked) mathActual += hours
                }
                "mf_final" -> {
                    revPlanned += hours
                    if (isChecked) revActual += hours
                }
                
                "sat_morning" -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
                "sat_flexible" -> {
                    chemistryPlanned += hours
                    if (isChecked) chemistryActual += hours
                }
                "sat_school_study" -> {
                    mathPlanned += hours
                    if (isChecked) mathActual += hours
                }
                "sat_afternoon" -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
                "sat_final" -> {
                    val split = hours / 2.0
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        chemistryActual += split
                        mathActual += split
                    }
                }

                "sun1_morning" -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
                "sun1_exam" -> {
                    val split = hours / 3.0
                    physicsPlanned += split
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        physicsActual += split
                        chemistryActual += split
                        mathActual += split
                    }
                }
                "sun1_review" -> {
                    revPlanned += hours
                    if (isChecked) revActual += hours
                }
                "sun1_evening" -> {
                    val split = hours / 3.0
                    physicsPlanned += split
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        physicsActual += split
                        chemistryActual += split
                        mathActual += split
                    }
                }

                "sun2_morning" -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
                "sun2_exam1" -> {
                    val split = hours / 3.0
                    physicsPlanned += split
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        physicsActual += split
                        chemistryActual += split
                        mathActual += split
                    }
                }
                "sun2_exam2" -> {
                    val split = hours / 3.0
                    physicsPlanned += split
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        physicsActual += split
                        chemistryActual += split
                        mathActual += split
                    }
                }
                "sun2_evening" -> {
                    val split = hours / 3.0
                    physicsPlanned += split
                    chemistryPlanned += split
                    mathPlanned += split
                    if (isChecked) {
                        physicsActual += split
                        chemistryActual += split
                        mathActual += split
                    }
                }

                "sun3_morning" -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
                "sun3_afternoon" -> {
                    chemistryPlanned += hours
                    if (isChecked) chemistryActual += hours
                }
                "sun3_evening" -> {
                    mathPlanned += hours
                    if (isChecked) mathActual += hours
                }
                
                else -> {
                    physicsPlanned += hours
                    if (isChecked) physicsActual += hours
                }
            }
        }

        val subjectReports = mutableListOf<SubjectProgressReport>()
        if (physicsPlanned > 0) {
            subjectReports.add(SubjectProgressReport("Physics", physicsPlanned, physicsActual, (physicsActual / physicsPlanned).toFloat().coerceIn(0f, 1f)))
        }
        if (chemistryPlanned > 0) {
            subjectReports.add(SubjectProgressReport("Chemistry", chemistryPlanned, chemistryActual, (chemistryActual / chemistryPlanned).toFloat().coerceIn(0f, 1f)))
        }
        if (mathPlanned > 0) {
            subjectReports.add(SubjectProgressReport("Mathematics", mathPlanned, mathActual, (mathActual / mathPlanned).toFloat().coerceIn(0f, 1f)))
        }
        if (revPlanned > 0) {
            subjectReports.add(SubjectProgressReport("Revision & Planning", revPlanned, revActual, (revActual / revPlanned).toFloat().coerceIn(0f, 1f)))
        }

        return DailyProgressReport(
            dateStr = getIndiaDateString(),
            totalPlannedHours = totalPlanned,
            totalActualHours = totalActual,
            subjectReports = subjectReports
        )
    }
}

data class SubjectProgressReport(
    val subjectName: String,
    val plannedHours: Double,
    val actualHours: Double,
    val progressPercent: Float
)

data class DailyProgressReport(
    val dateStr: String,
    val totalPlannedHours: Double,
    val totalActualHours: Double,
    val subjectReports: List<SubjectProgressReport>
)

data class CurrentScheduleStatus(
    val dayName: String,
    val timeStr: String,
    val activeSlot: ScheduleSlot,
    val minutesRemaining: Int,
    val isOutOfSchedule: Boolean,
    val graceMinsRemaining: Int,
    val dayOfWeek: Int
)
