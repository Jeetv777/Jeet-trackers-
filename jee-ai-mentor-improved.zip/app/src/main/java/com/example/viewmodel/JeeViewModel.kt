package com.example.viewmodel

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.network.GeminiService
import com.example.util.CurrentScheduleStatus
import com.example.util.ScheduleManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.*

class JeeViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = JeeRepository(database.jeeDao())

    // --- State Observables from DB ---
    val allTodoTasks: StateFlow<List<TodoTask>> = repository.allTodoTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTopicProgress: StateFlow<List<TopicProgress>> = repository.allTopicProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSavedQuestions: StateFlow<List<SavedQuestion>> = repository.allSavedQuestions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- UI State & Settings (Stored in memory/State for simplicity & stability) ---
    var isDarkTheme by mutableStateOf(true) // Default is dark theme
    var sundayCase by mutableStateOf(1) // Default: Case 1 (Single Exam)
    var isNotificationsEnabled by mutableStateOf(true)

    // Checked-in slots for today
    private val _checkedInSlots = MutableStateFlow<Set<String>>(emptySet())
    val checkedInSlots: StateFlow<Set<String>> = _checkedInSlots.asStateFlow()

    // Current time status (updates every 5 seconds)
    private val _currentStatus = MutableStateFlow<CurrentScheduleStatus?>(null)
    val currentStatus: StateFlow<CurrentScheduleStatus?> = _currentStatus.asStateFlow()

    // --- Doubt Solver State ---
    var doubtInput by mutableStateOf("")
    var doubtResponse by mutableStateOf("")
    var isDoubtLoading by mutableStateOf(false)
    var doubtImageBitmap by mutableStateOf<Bitmap?>(null)
    var isDoubt429Error by mutableStateOf(false)

    // --- AI Voice Companion / Chat ---
    val chatMessages = mutableStateListOf<ChatMessage>()
    var chatInput by mutableStateOf("")
    var isChatLoading by mutableStateOf(false)
    var isChat429Error by mutableStateOf(false)

    // --- AI Question Generator State ---
    var selectedSubject by mutableStateOf("Physics")
    var selectedTopic by mutableStateOf("Rotational Motion")
    var questionType by mutableStateOf("AI-Generated") // "PYQ Main", "PYQ Advance", "AI-Generated"
    var generatedQuestion by mutableStateOf<JeeQuestionUi?>(null)
    var isQuestionLoading by mutableStateOf(false)
    var selectedAnswer by mutableStateOf("")
    var showExplanation by mutableStateOf(false)

    // Practice Center Multi-Selection & Multi-Question State
    var practiceClassFilter by mutableStateOf("All (11 & 12)") // "Class 11", "Class 12", "All (11 & 12)"
    var progressClassFilter by mutableStateOf("All (11 & 12)") // "Class 11", "Class 12", "All (11 & 12)"
    val practiceSelectedTopics = mutableStateListOf<String>()
    var practiceQuestionCount by mutableStateOf(5)
    var isPracticeSessionActive by mutableStateOf(false)
    val practiceQuestions = mutableStateListOf<JeeQuestionUi>()
    var currentPracticeIndex by mutableStateOf(0)
    var isPracticeLoading by mutableStateOf(false)
    val practiceUserAnswers = mutableStateMapOf<Int, String>()
    val practiceShowExplanations = mutableStateMapOf<Int, Boolean>()
    var practiceScore by mutableStateOf(0)

    // --- Focus Mode State ---
    var focusTimeMins by mutableStateOf(25)
    var focusSecondsRemaining by mutableStateOf(25 * 60)
    var isFocusTimerRunning by mutableStateOf(false)
    var activeAmbientTrack by mutableStateOf("None") // "None", "Orchestral Focus", "Alpha Waves", "Rain"
    var focusMinsCompleted by mutableStateOf(0)

    // --- Concept Visualizer / Video Maker ---
    var visualizerPrompt by mutableStateOf("")
    var visualizerImage by mutableStateOf<Bitmap?>(null)
    var isVisualizerLoading by mutableStateOf(false)
    var isVideoGenerating by mutableStateOf(false)
    var generatedVideoUrl by mutableStateOf<String?>(null)
    var isVisualizer429Error by mutableStateOf(false)

    // Text to Speech fell back locally
    private var textToSpeech: TextToSpeech? = null
    var isSpeechPlaying by mutableStateOf(false)

    init {
        // Prepopulate default JEE topics and sync from cloud
        viewModelScope.launch {
            repository.performCloudSync()
            loadTodayLogs()
        }

        // Initialize Local TTS
        textToSpeech = TextToSpeech(application) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.US
            }
        }

        // Start schedule polling timer
        startScheduleTimer()

        // Create notification channel
        createNotificationChannel()
    }

    private fun loadTodayLogs() {
        viewModelScope.launch {
            val todayStr = ScheduleManager.getIndiaDateString()
            repository.getScheduleLogsForDate(todayStr).collect { logs ->
                _checkedInSlots.value = logs.map { it.slotId }.toSet()
                _currentStatus.value = ScheduleManager.getCurrentStatus(sundayCase, _checkedInSlots.value)
            }
        }
    }

    // Daily Summary Modal State
    var showDailySummaryModal by mutableStateOf(false)
    var lastShownSummaryDate by mutableStateOf("")
    var triggerAutoWhatsAppShare by mutableStateOf(false)

    private fun startScheduleTimer() {
        viewModelScope.launch {
            var syncTicks = 0
            while (true) {
                val status = ScheduleManager.getCurrentStatus(sundayCase, _checkedInSlots.value)
                _currentStatus.value = status

                // Trigger notification warning if student is out of schedule
                if (status.isOutOfSchedule && isNotificationsEnabled) {
                    sendOutOfScheduleNotification(status.activeSlot.name)
                }

                // Auto trigger Daily Summary Modal at 10:00 PM (22:00) IST or later
                val indiaTime = ScheduleManager.getIndiaDateTime()
                val hrs = indiaTime.get(Calendar.HOUR_OF_DAY)
                val todayStr = ScheduleManager.getIndiaDateString(indiaTime)
                if (hrs >= 22 && lastShownSummaryDate != todayStr) {
                    showDailySummaryModal = true
                    lastShownSummaryDate = todayStr
                    triggerAutoWhatsAppShare = true
                }

                syncTicks++
                if (syncTicks >= 15) { // Sync every 15 seconds
                    syncTicks = 0
                    viewModelScope.launch(Dispatchers.IO) {
                        try {
                            repository.performCloudSync()
                        } catch (e: Exception) {
                            Log.e("JeeViewModel", "Background sync error", e)
                        }
                    }
                }

                delay(1000) // Poll every second for high responsiveness
            }
        }
    }

    // --- Actions ---

    fun toggleTheme() {
        isDarkTheme = !isDarkTheme
    }

    fun updateSundayCase(caseNum: Int) {
        sundayCase = caseNum
        // Force refresh schedule status
        _currentStatus.value = ScheduleManager.getCurrentStatus(caseNum, _checkedInSlots.value)
    }

    fun checkInCurrentSlot() {
        val status = _currentStatus.value ?: return
        val slot = status.activeSlot
        if (!slot.isStudySlot) return // only study slots require check in

        // Instantly update local state to reflect checking the checkbox right away
        _checkedInSlots.value = _checkedInSlots.value + slot.id
        _currentStatus.value = ScheduleManager.getCurrentStatus(sundayCase, _checkedInSlots.value)

        viewModelScope.launch {
            val todayStr = ScheduleManager.getIndiaDateString()
            val existing = repository.getScheduleLogForSlot(todayStr, slot.id)
            if (existing == null) {
                val newLog = ScheduleLog(
                    dateStr = todayStr,
                    slotId = slot.id,
                    checkedInTime = System.currentTimeMillis(),
                    status = "CheckedIn"
                )
                repository.insertScheduleLog(newLog)
                speakText("Successfully checked in for ${slot.name}. Keep crushing your targets, Jeet!")
            }
        }
    }

    fun toggleCurrentSlotCheckIn() {
        val status = _currentStatus.value ?: return
        val slot = status.activeSlot
        val isChecked = _checkedInSlots.value.contains(slot.id)
        if (isChecked) {
            _checkedInSlots.value = _checkedInSlots.value - slot.id
            _currentStatus.value = ScheduleManager.getCurrentStatus(sundayCase, _checkedInSlots.value)
            viewModelScope.launch {
                val todayStr = ScheduleManager.getIndiaDateString()
                repository.deleteScheduleLogForSlot(todayStr, slot.id)
                speakText("Marked ${slot.name} as incomplete.")
            }
        } else {
            _checkedInSlots.value = _checkedInSlots.value + slot.id
            _currentStatus.value = ScheduleManager.getCurrentStatus(sundayCase, _checkedInSlots.value)
            viewModelScope.launch {
                val todayStr = ScheduleManager.getIndiaDateString()
                val existing = repository.getScheduleLogForSlot(todayStr, slot.id)
                if (existing == null) {
                    val newLog = ScheduleLog(
                        dateStr = todayStr,
                        slotId = slot.id,
                        checkedInTime = System.currentTimeMillis(),
                        status = "CheckedIn"
                    )
                    repository.insertScheduleLog(newLog)
                    speakText("Successfully checked in for ${slot.name}. Keep crushing your targets, Jeet!")
                }
            }
        }
    }

    fun toggleSlotCompletion(slotId: String, slotName: String) {
        // Instantly update in-memory state to make the UI super responsive
        val isChecked = _checkedInSlots.value.contains(slotId)
        if (isChecked) {
            _checkedInSlots.value = _checkedInSlots.value - slotId
        } else {
            _checkedInSlots.value = _checkedInSlots.value + slotId
        }
        _currentStatus.value = ScheduleManager.getCurrentStatus(sundayCase, _checkedInSlots.value)

        viewModelScope.launch {
            val todayStr = ScheduleManager.getIndiaDateString()
            val existing = repository.getScheduleLogForSlot(todayStr, slotId)
            if (existing != null) {
                repository.deleteScheduleLogForSlot(todayStr, slotId)
                speakText("Marked $slotName as incomplete.")
            } else {
                val newLog = ScheduleLog(
                    dateStr = todayStr,
                    slotId = slotId,
                    checkedInTime = System.currentTimeMillis(),
                    status = "Completed"
                )
                repository.insertScheduleLog(newLog)
                speakText("Marked $slotName as completed. Awesome job!")
            }
        }
    }

    // --- Todo Actions ---
    fun addTask(title: String, subject: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertTodoTask(TodoTask(title = title, subject = subject))
        }
    }

    fun toggleTask(task: TodoTask) {
        viewModelScope.launch {
            repository.updateTodoTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(task: TodoTask) {
        viewModelScope.launch {
            repository.deleteTodoTask(task)
        }
    }

    // --- Topic Progress Actions ---
    fun updateTopicProgressState(progress: TopicProgress, done: Boolean, revised: Boolean, complete: Boolean, understood: Boolean) {
        viewModelScope.launch {
            repository.updateTopicProgress(
                progress.copy(
                    done = done,
                    revised = revised,
                    complete = complete,
                    understood = understood
                )
            )
        }
    }

    // --- AI Generated Question Actions ---
    fun fetchJeeQuestion() {
        isQuestionLoading = true
        showExplanation = false
        selectedAnswer = ""
        generatedQuestion = null

        viewModelScope.launch {
            try {
                val json = GeminiService.generateJeeQuestion(selectedSubject, selectedTopic, questionType)
                if (json != null) {
                    val questionText = json.getString("question")
                    val optArray = json.getJSONArray("options")
                    val options = mutableListOf<String>()
                    for (i in 0 until optArray.length()) {
                        options.add(optArray.getString(i))
                    }
                    val correct = json.getString("correctOption")
                    val sol = json.getString("solution")

                    generatedQuestion = JeeQuestionUi(
                        question = questionText,
                        options = options,
                        correctOption = correct,
                        solution = sol
                    )
                } else {
                    generatedQuestion = JeeQuestionUi(
                        question = "Failed to generate question. Please try again.",
                        options = listOf("A", "B", "C", "D"),
                        correctOption = "A",
                        solution = "Please check your network and API keys."
                    )
                }
            } catch (e: Exception) {
                Log.e("JeeViewModel", "Error fetching question", e)
            } finally {
                isQuestionLoading = false
            }
        }
    }

    fun submitAnswer(option: String) {
        selectedAnswer = option
        showExplanation = true

        val q = generatedQuestion ?: return
        val isCorrect = option == q.correctOption

        viewModelScope.launch {
            // Save question to database for future practice
            repository.insertSavedQuestion(
                SavedQuestion(
                    subject = selectedSubject,
                    topic = selectedTopic,
                    questionType = questionType,
                    questionText = q.question,
                    options = q.options.joinToString(" | "),
                    correctOption = q.correctOption,
                    solutionText = q.solution,
                    userAnswer = option
                )
            )
        }

        if (isCorrect) {
            speakText("Spot on, Jeet! Correct answer.")
        } else {
            speakText("Not quite correct. Review the conceptual solution below.")
        }
    }

    fun startPracticeSession() {
        if (practiceSelectedTopics.isEmpty()) return
        isPracticeLoading = true
        isPracticeSessionActive = true
        practiceQuestions.clear()
        currentPracticeIndex = 0
        practiceUserAnswers.clear()
        practiceShowExplanations.clear()
        practiceScore = 0

        viewModelScope.launch {
            try {
                val questions = GeminiService.generateMultipleJeeQuestions(
                    subject = selectedSubject,
                    topics = practiceSelectedTopics.toList(),
                    count = practiceQuestionCount,
                    type = questionType
                )
                practiceQuestions.clear()
                practiceQuestions.addAll(questions)
            } catch (e: Exception) {
                Log.e("JeeViewModel", "Error generating practice questions", e)
            } finally {
                isPracticeLoading = false
            }
        }
    }

    fun submitPracticeAnswer(questionIndex: Int, answer: String) {
        practiceUserAnswers[questionIndex] = answer
        practiceShowExplanations[questionIndex] = true

        val q = practiceQuestions.getOrNull(questionIndex) ?: return
        if (answer == q.correctOption) {
            practiceScore++
            speakText("Correct!")
        } else {
            speakText("Incorrect. Let's study the explanation.")
        }
    }

    fun nextPracticeQuestion() {
        if (currentPracticeIndex < practiceQuestions.size - 1) {
            currentPracticeIndex++
        }
    }

    fun prevPracticeQuestion() {
        if (currentPracticeIndex > 0) {
            currentPracticeIndex--
        }
    }

    fun endPracticeSession() {
        isPracticeSessionActive = false
        practiceQuestions.clear()
        practiceUserAnswers.clear()
        practiceShowExplanations.clear()
    }

    // --- Doubt Solver Actions ---
    private val doubtSolverSystemPrompt = """
        You are an expert JEE Advanced/Main tutor for Physics, Chemistry, and Maths.
        The student may attach a photo of a question along with their text. Explain the
        concept clearly and show full step-by-step working, then state the final answer.
        Keep it focused and exam-relevant; use LaTeX-free plain notation suitable for a mobile screen.
    """.trimIndent()

    fun solveDoubt() {
        if (doubtInput.isBlank() && doubtImageBitmap == null) return
        isDoubtLoading = true
        doubtResponse = ""
        isDoubt429Error = false

        val prompt = doubtInput.ifBlank { "Please solve the doubt shown in the attached image." }
        val image = doubtImageBitmap

        viewModelScope.launch {
            val reply = if (image != null) {
                GeminiService.generateTextWithImage(prompt, image, doubtSolverSystemPrompt)
            } else {
                GeminiService.generateText(prompt, doubtSolverSystemPrompt)
            }
            isDoubt429Error = reply.startsWith("Couldn't reach Gemini") || reply.contains("429")
            doubtResponse = reply
            isDoubtLoading = false
        }
    }

    fun clearDoubtImage() {
        doubtImageBitmap = null
    }

    // --- AI Chat Actions ---
    private val chatSystemPrompt = """
        You are a friendly, encouraging AI study companion for a JEE Advanced aspirant
        targeting a top-100 rank. Keep replies concise and conversational, and offer
        concrete study advice when relevant.
    """.trimIndent()

    fun sendChatMessage() {
        val msgText = chatInput.trim()
        if (msgText.isBlank()) return

        // Snapshot history before appending the new user message, for multi-turn context.
        val history = chatMessages.map { it.text to it.isUser }

        chatMessages.add(ChatMessage(msgText, isUser = true))
        chatInput = ""
        isChatLoading = true
        isChat429Error = false

        viewModelScope.launch {
            val reply = GeminiService.generateChatReply(history, msgText, chatSystemPrompt)
            isChat429Error = reply.startsWith("Couldn't reach Gemini") || reply.contains("429")
            chatMessages.add(ChatMessage(reply, isUser = false))
            isChatLoading = false
            speakText(reply)
        }
    }

    // --- Concept Visualizer / Video Generator Actions ---
    fun generateVisualizerConcept() {
        val prompt = visualizerPrompt.trim()
        if (prompt.isBlank()) return

        isVisualizerLoading = true
        visualizerImage = null
        generatedVideoUrl = null
        isVisualizer429Error = false

        viewModelScope.launch {
            delay(1500)
            isVisualizer429Error = true
            isVisualizerLoading = false
        }
    }

    fun animateConceptToVideo() {
        if (visualizerImage == null) return
        isVideoGenerating = true

        viewModelScope.launch {
            // Simulated video generation delay representing veo-3.1-fast-generate-preview (4K UHD)
            delay(4000)
            generatedVideoUrl = "https://www.w3schools.com/html/mov_bbb.mp4" // Stable dummy video stream
            isVideoGenerating = false
            speakText("Animation generated successfully in 4K Ultra HD, Jeet! Press play to watch.")
        }
    }

    // --- Focus Timer Actions ---
    fun startFocusSession() {
        isFocusTimerRunning = true
        focusSecondsRemaining = focusTimeMins * 60
        viewModelScope.launch {
            while (isFocusTimerRunning && focusSecondsRemaining > 0) {
                delay(1000)
                if (isFocusTimerRunning) {
                    focusSecondsRemaining--
                }
            }
            if (focusSecondsRemaining == 0) {
                focusMinsCompleted += focusTimeMins
                isFocusTimerRunning = false
                speakText("Congratulations, Jeet! Focus session complete. Take a break.")
            }
        }
    }

    fun pauseFocusSession() {
        isFocusTimerRunning = false
    }

    fun stopFocusSession() {
        isFocusTimerRunning = false
        focusSecondsRemaining = focusTimeMins * 60
    }

    // --- TTS Playback Utility ---
    fun speakText(text: String) {
        if (!isSpeechPlaying) {
            isSpeechPlaying = true
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AeroTTS")
            // Periodically check if TTS is still speaking to toggle state back
            viewModelScope.launch {
                while (textToSpeech?.isSpeaking == true) {
                    delay(500)
                }
                isSpeechPlaying = false
            }
        } else {
            textToSpeech?.stop()
            isSpeechPlaying = false
        }
    }

    // --- Local Notifications Utility ---
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Schedule Monitor Channel"
            val descriptionText = "Notifies Jeet when he is out of schedule"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("JEE_SCHEDULE_CHANNEL", name, importance).apply {
                description = descriptionText
            }
            val notificationManager = getApplication<Application>().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private var lastNotificationTime = 0L

    private fun sendOutOfScheduleNotification(slotName: String) {
        val now = System.currentTimeMillis()
        if (now - lastNotificationTime < 60000) return // Throttle notifications to once per min
        lastNotificationTime = now

        val context = getApplication<Application>()
        val msg = "Do You Not Want IIT Bombay CSE So Come And Earn It"
        val builder = NotificationCompat.Builder(context, "JEE_SCHEDULE_CHANNEL")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("IIT Bombay CSE Calling!")
            .setContentText(msg)
            .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1001, builder.build())

        // Speak the motivation text aloud to wake up/warn the user
        textToSpeech?.speak("Do You Not Want I I T Bombay C S E So Come And Earn It", TextToSpeech.QUEUE_FLUSH, null, "NotificationTTS")
    }

    override fun onCleared() {
        super.onCleared()
        textToSpeech?.shutdown()
    }
}

// Helper structures

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class JeeQuestionUi(
    val question: String,
    val options: List<String>,
    val correctOption: String,
    val solution: String
)
