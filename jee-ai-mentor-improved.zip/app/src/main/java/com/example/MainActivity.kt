package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import java.util.Calendar
import com.example.util.ScheduleManager
import com.example.util.ScheduleSlot
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.data.TopicProgress
import com.example.data.JeeChapter
import com.example.data.ALL_JEE_CHAPTERS
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.JeeViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: JeeViewModel = viewModel()
            MyApplicationTheme(darkTheme = viewModel.isDarkTheme) {
                MainContent(viewModel)
            }
        }
    }
}

fun shareReportToWhatsApp(context: android.content.Context, phoneNumber: String, reportText: String) {
    try {
        val url = "https://api.whatsapp.com/send?phone=$phoneNumber&text=${java.net.URLEncoder.encode(reportText, "UTF-8")}"
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse(url)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "WhatsApp is not installed or error opening.", android.widget.Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun TopClockBar(viewModel: JeeViewModel, activeTab: String) {
    val currentStatus by viewModel.currentStatus.collectAsState()
    val isDark = viewModel.isDarkTheme

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "IIT Wings",
                    tint = com.example.ui.theme.CosmicGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    val pageTitle = when (activeTab) {
                        "Schedule" -> "JEE Schedule Timeline"
                        "Progress" -> "Syllabus Mastery Tracker"
                        "Practice" -> "Custom Practice Engine"
                        "DoubtSolver" -> "Math & Physics AI Solver"
                        "Focus" -> "Golden Hour Deep Focus"
                        "Aero" -> "Aero AI Chat Companion"
                        "VisualLab" -> "Veo 4K Physics Visualizer"
                        "Settings" -> "System Configuration"
                        else -> "IIT Companion"
                    }
                    Text(
                        text = pageTitle,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Fly with Golden Wings to IIT Bombay",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = com.example.ui.theme.CosmicGold
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = com.example.ui.theme.CosmicGold.copy(alpha = 0.15f)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, com.example.ui.theme.CosmicGold.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Clock",
                        tint = com.example.ui.theme.CosmicGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = currentStatus?.timeStr ?: "--:--",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isDark) Color.White else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("top_live_clock")
                        )
                        Text(
                            text = "India Time (IST)",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DailySummaryModal(viewModel: JeeViewModel) {
    val context = LocalContext.current
    val currentStatus by viewModel.currentStatus.collectAsState()
    val checkedInSlots by viewModel.checkedInSlots.collectAsState()
    
    val sundayCase = viewModel.sundayCase
    val dayOfWeek = currentStatus?.dayOfWeek ?: Calendar.MONDAY
    
    val report = remember(dayOfWeek, sundayCase, checkedInSlots) {
        ScheduleManager.getDailyProgressReport(dayOfWeek, sundayCase, checkedInSlots)
    }

    val isUserLoggedIn = checkedInSlots.isNotEmpty()
    val finalPlanned = report.totalPlannedHours
    val finalActual = if (isUserLoggedIn) report.totalActualHours else finalPlanned
    val progressPercent = if (finalPlanned > 0) (finalActual / finalPlanned) else 1.0

    androidx.compose.ui.window.Dialog(onDismissRequest = { viewModel.showDailySummaryModal = false }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(24.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(2.dp, com.example.ui.theme.CosmicGold)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(com.example.ui.theme.CosmicGold.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Golden Wings",
                        tint = com.example.ui.theme.CosmicGold,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "JEET'S DAILY IIT PROGRESS REPORT",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = com.example.ui.theme.CosmicGold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Daily Performance Audit & Motivation",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("PLANNED TIME", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text(
                            text = String.format("%.1f hrs", finalPlanned),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("STUDIED TIME", fontSize = 10.sp, color = com.example.ui.theme.CosmicGold)
                        Text(
                            text = String.format("%.1f hrs", finalActual),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = com.example.ui.theme.CosmicGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Overall Study Progress",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start).padding(bottom = 8.dp)
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Schedule Efficiency",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = String.format("%.1f / %.1f hrs (%d%%)", finalActual, finalPlanned, (progressPercent * 100).toInt()),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progressPercent.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp)),
                        color = com.example.ui.theme.CosmicGold,
                        trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (finalActual >= finalPlanned) {
                            "\"Superb work, Jeet! You studied with the focus of a top 100 IITian today. The golden wings of success are yours to earn.\""
                        } else {
                            "\"To fly with golden wings to IIT, you must close the gap. Tomorrow is a new battle—bring back the 100% effort!\""
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = com.example.ui.theme.CosmicGold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Share Report via WhatsApp",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = com.example.ui.theme.CosmicGold,
                    modifier = Modifier.align(Alignment.Start).padding(bottom = 8.dp)
                )

                val contacts = listOf(
                    Triple("Jeet", "+917990954542", "🇮🇳"),
                    Triple("Dad", "+265999753101", "🇲🇼"),
                    Triple("Mom", "+26599854660", "🇲🇼"),
                    Triple("Dada", "+919427155575", "🇮🇳"),
                    Triple("Dadi", "+91965011771", "🇮🇳")
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    contacts.forEachIndexed { index, contact ->
                        val (name, phone, flag) = contact
                        Button(
                            onClick = {
                                val shareMsg = """
                                    *JEE ADVANCED DAILY REPORT* 
                                    Date: ${report.dateStr}
                                    
                                    *Today's Study Summary:*
                                    Planned Time: ${String.format("%.1f", finalPlanned)} hours
                                    Studied Time: ${String.format("%.1f", finalActual)} hours
                                    Schedule Efficiency: ${(progressPercent * 100).toInt()}%
                                    
                                    *Wings of IIT Bombay Directives:*
                                    ${if (finalActual >= finalPlanned) "Earned 100% schedule efficiency. IIT Bombay CSE calling!" else "Must push harder tomorrow to earn golden wings!"}
                                """.trimIndent()
                                shareReportToWhatsApp(context, phone, shareMsg)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("modal_whatsapp_share_btn_$index"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = flag, fontSize = 16.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(horizontalAlignment = Alignment.Start) {
                                        Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                        Text(phone, fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f))
                                    }
                                }
                                Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = { viewModel.showDailySummaryModal = false },
                    modifier = Modifier.fillMaxWidth().testTag("modal_close_btn")
                ) {
                    Text("Close", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@Composable
fun MainContent(viewModel: JeeViewModel) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf("Schedule") }

    // Request permissions for notifications on startup (Android 13+)
    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.isNotificationsEnabled = true
        } else {
            Toast.makeText(context, "Notification permission denied. Alert notifications disabled.", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(viewModel.triggerAutoWhatsAppShare) {
        if (viewModel.triggerAutoWhatsAppShare) {
            viewModel.triggerAutoWhatsAppShare = false
            try {
                val currentStatus = viewModel.currentStatus.value
                val sundayCase = viewModel.sundayCase
                val dayOfWeek = currentStatus?.dayOfWeek ?: Calendar.MONDAY
                val checkedInSlots = viewModel.checkedInSlots.value
                val report = ScheduleManager.getDailyProgressReport(dayOfWeek, sundayCase, checkedInSlots)
                
                val isUserLoggedIn = checkedInSlots.isNotEmpty()
                val finalPlanned = report.totalPlannedHours
                val finalActual = if (isUserLoggedIn) report.totalActualHours else finalPlanned
                val progressPercent = if (finalPlanned > 0) (finalActual / finalPlanned) else 1.0
                
                val shareMsg = """
                    *JEE ADVANCED DAILY REPORT* 
                    Date: ${report.dateStr}
                    
                    *Today's Study Summary:*
                    Planned Time: ${String.format("%.1f", finalPlanned)} hours
                    Studied Time: ${String.format("%.1f", finalActual)} hours
                    Schedule Efficiency: ${(progressPercent * 100).toInt()}%
                    
                    *Wings of IIT Bombay Directives:*
                    ${if (finalActual >= finalPlanned) "Earned 100% schedule efficiency. IIT Bombay CSE calling!" else "Must push harder tomorrow to earn golden wings!"}
                """.trimIndent()
                
                shareReportToWhatsApp(context, "+917990954542", shareMsg)
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error auto sharing report on WhatsApp", e)
            }
        }
    }

    // Overlay modal display for Daily Summary
    if (viewModel.showDailySummaryModal) {
        DailySummaryModal(viewModel = viewModel)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isCompactSidebar = maxWidth < 600.dp
        val isWideScreenForContent = maxWidth >= 720.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Left side Navigation Sidebar (compact/rail style for mobile, full for wide screens)
            NavigationSidebar(
                activeTab = activeTab,
                isCompact = isCompactSidebar,
                onTabSelected = { activeTab = it }
            )

            // Right side Main Content Area
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Persistent Dynamic Header displaying India Time (IST) & Active tab status
                TopClockBar(viewModel = viewModel, activeTab = activeTab)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    // Screen switcher
                    when (activeTab) {
                        "Schedule" -> ScheduleScreen(viewModel, isWideScreen = isWideScreenForContent)
                        "Progress" -> ProgressScreen(viewModel)
                        "Practice" -> PracticeScreen(viewModel)
                        "DoubtSolver" -> DoubtSolverScreen(viewModel)
                        "Focus" -> FocusScreen(viewModel)
                        "Aero" -> AeroChatScreen(viewModel)
                        "VisualLab" -> VisualLabScreen(viewModel)
                        "Settings" -> SettingsScreen(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(activeTab: String, onTabSelected: (String) -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.shadow(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple("Schedule", Icons.Default.Schedule, "Schedule"),
                Triple("Progress", Icons.Default.BarChart, "Progress"),
                Triple("Practice", Icons.Default.MenuBook, "Practice"),
                Triple("DoubtSolver", Icons.Default.HelpCenter, "Doubt"),
                Triple("Focus", Icons.Default.Timer, "Focus"),
                Triple("Aero", Icons.Default.Psychology, "Aero"),
                Triple("VisualLab", Icons.Default.Science, "Lab"),
                Triple("Settings", Icons.Default.Settings, "Config")
            )

            items.forEach { (tab, icon, label) ->
                val isSelected = activeTab == tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("nav_tab_$tab")
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
fun NavigationSidebar(activeTab: String, isCompact: Boolean, onTabSelected: (String) -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        modifier = Modifier
            .fillMaxHeight()
            .width(if (isCompact) 72.dp else 260.dp)
            .shadow(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(if (isCompact) 8.dp else 24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Header / Branding Section
                if (isCompact) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_app_icon_1783843053934),
                        contentDescription = "JEE Tracker Logo",
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .padding(bottom = 8.dp),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 24.dp).fillMaxWidth()
                    ) {
                        Image(
                            painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_app_icon_1783843053934),
                            contentDescription = "JEE Tracker Logo",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Jeet's Portal",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Allen JEE Tracker",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), modifier = Modifier.padding(bottom = 16.dp))

                // Navigation Tabs
                val items = listOf(
                    Triple("Schedule", Icons.Default.Schedule, "Today's Schedule"),
                    Triple("Progress", Icons.Default.BarChart, "Syllabus Progress"),
                    Triple("Practice", Icons.Default.MenuBook, "Practice Center"),
                    Triple("DoubtSolver", Icons.Default.HelpCenter, "Doubt Solver"),
                    Triple("Focus", Icons.Default.Timer, "Focus Timer"),
                    Triple("Aero", Icons.Default.Psychology, "Aero AI Chat"),
                    Triple("VisualLab", Icons.Default.Science, "Visual Physics Lab"),
                    Triple("Settings", Icons.Default.Settings, "Config Settings")
                )

                items.forEach { (tab, icon, label) ->
                    val isSelected = activeTab == tab
                    val bgBrush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.03f)
                            )
                        )
                    } else {
                        null
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .then(if (bgBrush != null) Modifier.background(bgBrush) else Modifier)
                            .clickable { onTabSelected(tab) }
                            .padding(horizontal = if (isCompact) 4.dp else 16.dp, vertical = 12.dp)
                            .testTag("nav_tab_$tab"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = if (isCompact) Arrangement.Center else Arrangement.Start,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                modifier = Modifier.size(20.dp)
                            )
                            if (!isCompact) {
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = label,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }

            // User Information Footer
            if (isCompact) {
                Image(
                    painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                    contentDescription = "Jeet Avatar",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f))
                        .padding(12.dp)
                ) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                        contentDescription = "Jeet Avatar",
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Jeet Vachhani",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "IIT JEE Aspirant",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}

// ==================== 1. SCHEDULE SCREEN ====================
@Composable
fun ScheduleScreen(viewModel: JeeViewModel, isWideScreen: Boolean) {
    val currentStatus by viewModel.currentStatus.collectAsState()
    val checkedInSet by viewModel.checkedInSlots.collectAsState()

    if (isWideScreen) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Left Column: Complete timeline (Expanded view for desktop/full screen)
            Card(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "Today's Complete Timeline",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    currentStatus?.let { status ->
                        val slots = ScheduleManager.getSlotsForDay(status.dayOfWeek, viewModel.sundayCase)
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(slots) { slot ->
                                val isActive = slot.id == status.activeSlot.id
                                val isCheckedIn = checkedInSet.contains(slot.id)

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.toggleSlotCompletion(slot.id, slot.name) }
                                        .border(
                                            width = if (isActive) 2.dp else 0.dp,
                                            color = if (isActive) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            shape = RoundedCornerShape(12.dp)
                                        ),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.02f)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        Row(
                                            modifier = Modifier
                                                .padding(16.dp)
                                                .fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            if (isCheckedIn) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                                            else if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                                                        )
                                                        .border(
                                                            width = 1.dp,
                                                            color = if (isCheckedIn) MaterialTheme.colorScheme.primary
                                                            else if (isActive) MaterialTheme.colorScheme.primary
                                                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                                            shape = CircleShape
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (isCheckedIn) {
                                                        Image(
                                                            painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                                                            contentDescription = "Jeet Avatar Completed",
                                                            modifier = Modifier.fillMaxSize().clip(CircleShape),
                                                            contentScale = ContentScale.Crop
                                                        )
                                                    } else {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(10.dp)
                                                                .clip(CircleShape)
                                                                .background(
                                                                    if (isActive) MaterialTheme.colorScheme.primary
                                                                    else if (slot.isStudySlot) MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f)
                                                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                                                                )
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = slot.name,
                                                        fontSize = 14.sp,
                                                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                                        textDecoration = if (isCheckedIn) androidx.compose.ui.text.style.TextDecoration.LineThrough else androidx.compose.ui.text.style.TextDecoration.None,
                                                        color = if (isCheckedIn) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = if (slot.isStudySlot) "Study block" else "Break / Transition",
                                                        fontSize = 11.sp,
                                                        textDecoration = if (isCheckedIn) androidx.compose.ui.text.style.TextDecoration.LineThrough else androidx.compose.ui.text.style.TextDecoration.None,
                                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (isCheckedIn) 0.3f else 0.5f)
                                                    )
                                                }
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (slot.isStudySlot && isCheckedIn) {
                                                    Icon(
                                                        Icons.Default.Check,
                                                        contentDescription = "Done",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier
                                                            .size(18.dp)
                                                            .padding(end = 4.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "${slot.getFormattedStart()} – ${slot.getFormattedEnd()}",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    textDecoration = if (isCheckedIn) androidx.compose.ui.text.style.TextDecoration.LineThrough else androidx.compose.ui.text.style.TextDecoration.None,
                                                    color = if (isActive && !isCheckedIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = if (isCheckedIn) 0.3f else 0.6f)
                                                )
                                            }
                                        }

                                        if (isCheckedIn) {
                                            // Beautiful physical line cutting across the card with the user's avatar stamped in the center
                                            Box(
                                                modifier = Modifier
                                                    .matchParentSize()
                                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(2.5.dp)
                                                        .align(Alignment.Center)
                                                        .background(MaterialTheme.colorScheme.primary)
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .align(Alignment.Center)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.surface)
                                                        .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                                ) {
                                                    Image(
                                                        painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                                                        contentDescription = "Cut completed stamp",
                                                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                                                        contentScale = ContentScale.Crop
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right Column: Active status, Quick Action Check-in, Hero Details
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Hero Header Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Welcome back, Jeet!",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Allen JEE Advanced Tracker",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }
                            Image(
                                painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                                contentDescription = "Jeet Avatar",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(16.dp))

                        // Auto-detected Time details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Current Day",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = com.example.ui.theme.CosmicGold
                                )
                                Text(
                                    text = currentStatus?.dayName ?: "Auto detecting...",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "India Standard Time",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = com.example.ui.theme.CosmicGold
                                )
                                Text(
                                    text = currentStatus?.timeStr ?: "--:--",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                // Daily Progress Report Button
                Button(
                    onClick = { viewModel.showDailySummaryModal = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("wide_golden_report_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.CosmicGold),
                    shape = RoundedCornerShape(16.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Jeet Progress Report",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "View Jeet's Daily IIT Progress Report",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                }

                // Unified Active Slot Control Card (Persistent, Selectable & Deselectable)
                currentStatus?.let { status ->
                    if (status.activeSlot.isStudySlot) {
                        val isCheckedIn = checkedInSet.contains(status.activeSlot.id)
                        val isGracePeriod = status.graceMinsRemaining > 0
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    2.dp,
                                    if (isCheckedIn) MaterialTheme.colorScheme.primary
                                    else if (isGracePeriod) MaterialTheme.colorScheme.secondary
                                    else MaterialTheme.colorScheme.tertiary,
                                    RoundedCornerShape(16.dp)
                                ),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCheckedIn) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                else if (isGracePeriod) MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f)
                                else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.08f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isCheckedIn) "Checked In!" else if (isGracePeriod) "Grace Time Ticking!" else "Out of Schedule!",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCheckedIn) MaterialTheme.colorScheme.primary
                                        else if (isGracePeriod) MaterialTheme.colorScheme.secondary
                                        else MaterialTheme.colorScheme.tertiary
                                    )
                                    Text(
                                        text = if (isCheckedIn) "You are logged in and studying: '${status.activeSlot.name}' (${status.minutesRemaining} mins remaining)."
                                        else if (isGracePeriod) "You have ${status.graceMinsRemaining} mins to check in before alarm triggers (${status.minutesRemaining} mins left in slot)."
                                        else "You are study slot: '${status.activeSlot.name}' (${status.minutesRemaining} mins remaining). Please log in now!",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    )
                                }
                                Button(
                                    onClick = { viewModel.toggleCurrentSlotCheckIn() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isCheckedIn) MaterialTheme.colorScheme.primary
                                        else if (isGracePeriod) MaterialTheme.colorScheme.secondary
                                        else MaterialTheme.colorScheme.tertiary
                                    ),
                                    modifier = Modifier.testTag("check_in_button")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (isCheckedIn) {
                                            Icon(
                                                Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text("Checked In", color = Color.White)
                                        } else {
                                            Text("Check In", color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Active Slot Detail Card
                currentStatus?.let { status ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "ACTIVE SLOT",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = com.example.ui.theme.CosmicGold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = status.activeSlot.name,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = com.example.ui.theme.CosmicGold,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Timer,
                                            contentDescription = "Time Left",
                                            tint = Color.Black,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "${status.minutesRemaining} MINS REMAINING",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                    }
                                }
                                Text(
                                    text = "${status.activeSlot.getFormattedStart()} – ${status.activeSlot.getFormattedEnd()}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.95f)
                                )
                            }
                        }
                    }
                }

                // Sunday Case Selectors (Only shown if current day is Sunday)
                currentStatus?.let { status ->
                    if (status.dayOfWeek == Calendar.SUNDAY) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Sunday Mode Configuration",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val cases = listOf(
                                        Pair(1, "Single Exam"),
                                        Pair(2, "Double Exam"),
                                        Pair(3, "Full Study")
                                    )
                                    cases.forEach { (num, label) ->
                                        Button(
                                            onClick = { viewModel.updateSundayCase(num) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (viewModel.sundayCase == num) MaterialTheme.colorScheme.primary
                                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("sunday_case_btn_$num"),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (viewModel.sundayCase == num) Color.White else MaterialTheme.colorScheme.onSurface,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Mobile portrait layout: beautifully stacked scrolling column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Header Card (time, date)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Welcome, Jeet!",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Allen JEE Tracker",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        Image(
                            painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                            contentDescription = "Jeet Avatar",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Day",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.CosmicGold
                            )
                            Text(
                                text = currentStatus?.dayName ?: "Detecting...",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "India Time",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.CosmicGold
                            )
                            Text(
                                text = currentStatus?.timeStr ?: "--:--",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Daily Progress Report Button
            Button(
                onClick = { viewModel.showDailySummaryModal = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("mobile_golden_report_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.CosmicGold),
                shape = RoundedCornerShape(16.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Jeet Progress Report",
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "View Jeet's Daily IIT Progress Report",
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }

            // Unified Active Slot Control Card (Persistent, Selectable & Deselectable)
            currentStatus?.let { status ->
                if (status.activeSlot.isStudySlot) {
                    val isCheckedIn = checkedInSet.contains(status.activeSlot.id)
                    val isGracePeriod = status.graceMinsRemaining > 0
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                2.dp,
                                if (isCheckedIn) MaterialTheme.colorScheme.primary
                                else if (isGracePeriod) MaterialTheme.colorScheme.secondary
                                else MaterialTheme.colorScheme.tertiary,
                                RoundedCornerShape(16.dp)
                            ),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCheckedIn) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            else if (isGracePeriod) MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f)
                            else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.08f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = if (isCheckedIn) "Checked In!" else if (isGracePeriod) "Grace Time Ticking!" else "Out of Schedule!",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCheckedIn) MaterialTheme.colorScheme.primary
                                    else if (isGracePeriod) MaterialTheme.colorScheme.secondary
                                    else MaterialTheme.colorScheme.tertiary
                                )
                                Text(
                                    text = if (isCheckedIn) "You are logged in and studying: '${status.activeSlot.name}' (${status.minutesRemaining} mins left)."
                                    else if (isGracePeriod) "You have ${status.graceMinsRemaining} mins to check in (${status.minutesRemaining} mins left in slot)."
                                    else "You are study slot: '${status.activeSlot.name}' (${status.minutesRemaining} mins left). Please log in now!",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                            Button(
                                onClick = { viewModel.toggleCurrentSlotCheckIn() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCheckedIn) MaterialTheme.colorScheme.primary
                                    else if (isGracePeriod) MaterialTheme.colorScheme.secondary
                                    else MaterialTheme.colorScheme.tertiary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("check_in_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (isCheckedIn) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text("Checked In (Tap to Deselect)", color = Color.White, fontSize = 13.sp)
                                    } else {
                                        Text("Check In Now", color = Color.White, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Active Slot Detail
            currentStatus?.let { status ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ACTIVE SLOT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = com.example.ui.theme.CosmicGold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = status.activeSlot.name,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = com.example.ui.theme.CosmicGold,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Timer,
                                        contentDescription = "Time Left",
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "${status.minutesRemaining} MINS LEFT",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.Black
                                    )
                                }
                            }
                            Text(
                                text = "${status.activeSlot.getFormattedStart()} – ${status.activeSlot.getFormattedEnd()}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.95f)
                            )
                        }
                    }
                }
            }

            // Sunday Configuration (if applicable)
            currentStatus?.let { status ->
                if (status.dayOfWeek == Calendar.SUNDAY) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Sunday Mode",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val cases = listOf(
                                    Pair(1, "Single"),
                                    Pair(2, "Double"),
                                    Pair(3, "Full Study")
                                )
                                cases.forEach { (num, label) ->
                                    Button(
                                        onClick = { viewModel.updateSundayCase(num) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (viewModel.sundayCase == num) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("sunday_case_btn_$num"),
                                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (viewModel.sundayCase == num) Color.White else MaterialTheme.colorScheme.onSurface,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Timeline header and timeline items inside the scroll view
            Text(
                text = "Today's Complete Timeline",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )

            currentStatus?.let { status ->
                val slots = ScheduleManager.getSlotsForDay(status.dayOfWeek, viewModel.sundayCase)
                slots.forEach { slot ->
                    val isActive = slot.id == status.activeSlot.id
                    val isCheckedIn = checkedInSet.contains(slot.id)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.toggleSlotCompletion(slot.id, slot.name) }
                            .border(
                                width = if (isActive) 1.5.dp else 0.dp,
                                color = if (isActive) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.02f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isCheckedIn) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                                else if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = if (isCheckedIn) MaterialTheme.colorScheme.primary
                                                else if (isActive) MaterialTheme.colorScheme.primary
                                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isCheckedIn) {
                                            Image(
                                                painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                                                contentDescription = "Jeet Avatar Completed",
                                                modifier = Modifier.fillMaxSize().clip(CircleShape),
                                                contentScale = ContentScale.Crop
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isActive) MaterialTheme.colorScheme.primary
                                                        else if (slot.isStudySlot) MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f)
                                                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                                                    )
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = slot.name,
                                            fontSize = 13.sp,
                                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                            textDecoration = if (isCheckedIn) androidx.compose.ui.text.style.TextDecoration.LineThrough else androidx.compose.ui.text.style.TextDecoration.None,
                                            color = if (isCheckedIn) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (slot.isStudySlot) "Study block" else "Break / Transition",
                                            fontSize = 10.sp,
                                            textDecoration = if (isCheckedIn) androidx.compose.ui.text.style.TextDecoration.LineThrough else androidx.compose.ui.text.style.TextDecoration.None,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (isCheckedIn) 0.3f else 0.5f)
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (slot.isStudySlot && isCheckedIn) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = "Done",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .padding(end = 4.dp)
                                        )
                                    }
                                    Text(
                                        text = "${slot.getFormattedStart()} – ${slot.getFormattedEnd()}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        textDecoration = if (isCheckedIn) androidx.compose.ui.text.style.TextDecoration.LineThrough else androidx.compose.ui.text.style.TextDecoration.None,
                                        color = if (isActive && !isCheckedIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = if (isCheckedIn) 0.3f else 0.6f)
                                    )
                                }
                            }

                            if (isCheckedIn) {
                                // Beautiful physical line cutting across the card with the user's avatar stamped in the center
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(2.dp)
                                            .align(Alignment.Center)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .align(Alignment.Center)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                    ) {
                                        Image(
                                            painter = androidx.compose.ui.res.painterResource(id = R.drawable.img_jeet_avatar_1783844628062),
                                            contentDescription = "Cut completed stamp",
                                            modifier = Modifier.fillMaxSize().clip(CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== 2. PROGRESS SCREEN ====================
@Composable
fun ProgressScreen(viewModel: JeeViewModel) {
    var selectedSubjectTab by remember { mutableStateOf("Physics") }
    val topicList by viewModel.allTopicProgress.collectAsState()
    val filteredList = topicList.filter { topic ->
        topic.subject == selectedSubjectTab && when (viewModel.progressClassFilter) {
            "Class 11" -> {
                val chap = ALL_JEE_CHAPTERS.find { it.name == topic.topicName }
                chap?.classNum == 11
            }
            "Class 12" -> {
                val chap = ALL_JEE_CHAPTERS.find { it.name == topic.topicName }
                chap?.classNum == 12
            }
            else -> true // All
        }
    }

    // Calculate percentage completions for chart rendering
    val doneCount = filteredList.count { it.done }
    val revisedCount = filteredList.count { it.revised }
    val completeCount = filteredList.count { it.complete }
    val understoodCount = filteredList.count { it.understood }
    val totalCount = filteredList.size.coerceAtLeast(1)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Syllabus Track & Progress",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Subject Tabs Selectors
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val subjects = listOf("Physics", "Chemistry", "Maths")
            subjects.forEach { subject ->
                Button(
                    onClick = { selectedSubjectTab = subject },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSubjectTab == subject) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("progress_tab_$subject")
                ) {
                    Text(
                        text = subject,
                        color = if (selectedSubjectTab == subject) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Grade / Class Filter Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Class 11", "Class 12", "All (11 & 12)").forEach { grade ->
                val isSelected = viewModel.progressClassFilter == grade
                Button(
                    onClick = { viewModel.progressClassFilter = grade },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    Text(grade, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Custom Visual Progress Chart
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "$selectedSubjectTab Overall Mastery (${viewModel.progressClassFilter})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Custom graphic progress visualization
                val metrics = listOf(
                    Quad("Read/Done", doneCount, totalCount, MaterialTheme.colorScheme.primary),
                    Quad("Revised", revisedCount, totalCount, MaterialTheme.colorScheme.secondary),
                    Quad("Completed", completeCount, totalCount, MaterialTheme.colorScheme.tertiary),
                    Quad("Understood", understoodCount, totalCount, Color(0xFF10B981))
                )

                metrics.forEach { (label, count, total, color) ->
                    val ratio = count.toFloat() / total.toFloat()
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text("${(ratio * 100).toInt()}% ($count/$total)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(ratio)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(color)
                            )
                        }
                    }
                }
            }
        }

        // Topics Checklist
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredList) { topic ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        val classNum = ALL_JEE_CHAPTERS.find { it.name == topic.topicName }?.classNum
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = topic.topicName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            if (classNum != null) {
                                Text(
                                    text = "Class $classNum",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Progress state toggles Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            ProgressToggleCell(
                                label = "Done",
                                checked = topic.done,
                                onCheckedChange = { viewModel.updateTopicProgressState(topic, it, topic.revised, topic.complete, topic.understood) }
                            )
                            ProgressToggleCell(
                                label = "Revised",
                                checked = topic.revised,
                                onCheckedChange = { viewModel.updateTopicProgressState(topic, topic.done, it, topic.complete, topic.understood) }
                            )
                            ProgressToggleCell(
                                label = "Complete",
                                checked = topic.complete,
                                onCheckedChange = { viewModel.updateTopicProgressState(topic, topic.done, topic.revised, it, topic.understood) }
                            )
                            ProgressToggleCell(
                                label = "Understood",
                                checked = topic.understood,
                                onCheckedChange = { viewModel.updateTopicProgressState(topic, topic.done, topic.revised, topic.complete, it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun RowScope.ProgressToggleCell(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Column(
        modifier = Modifier
            .weight(1f)
            .clickable { onCheckedChange(!checked) }
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(
                    if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                )
                .border(
                    width = 1.dp,
                    color = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            color = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
    }
}

// ==================== 3. PRACTICE SCREEN ====================

@Composable
fun PracticeScreen(viewModel: JeeViewModel) {
    // Determine subject-specific filtered chapters
    val filteredChapters = ALL_JEE_CHAPTERS.filter { chap ->
        chap.subject == viewModel.selectedSubject && when (viewModel.practiceClassFilter) {
            "Class 11" -> chap.classNum == 11
            "Class 12" -> chap.classNum == 12
            else -> true // All
        }
    }

    if (!viewModel.isPracticeSessionActive) {
        // Practice Session Configuration Mode
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Aero Adaptive Practice Suite",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Configure and launch high-impact custom mock tests on any mix of chapters.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            // Subject Selector Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "1. Select Subject",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Physics", "Chemistry", "Maths").forEach { sub ->
                                val isSelected = viewModel.selectedSubject == sub
                                Button(
                                    onClick = {
                                        viewModel.selectedSubject = sub
                                        viewModel.practiceSelectedTopics.clear()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(sub, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Grade / Class Filter Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "2. Filter Chapters by Grade",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Class 11", "Class 12", "All (11 & 12)").forEach { grade ->
                                val isSelected = viewModel.practiceClassFilter == grade
                                Button(
                                    onClick = {
                                        viewModel.practiceClassFilter = grade
                                        viewModel.practiceSelectedTopics.clear()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) {
                                    Text(grade, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }

            // Topic Selector Checklist Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "3. Choose Chapter(s) (${viewModel.practiceSelectedTopics.size} selected)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = {
                                    viewModel.practiceSelectedTopics.clear()
                                    viewModel.practiceSelectedTopics.addAll(filteredChapters.map { it.name })
                                }) {
                                    Text("Select All", fontSize = 11.sp)
                                }
                                TextButton(onClick = {
                                    viewModel.practiceSelectedTopics.clear()
                                }) {
                                    Text("Clear All", fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp)
                                .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                .verticalScroll(rememberScrollState())
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (filteredChapters.isEmpty()) {
                                    Text("No chapters available under current filters.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                } else {
                                    filteredChapters.forEach { chap ->
                                        val checked = viewModel.practiceSelectedTopics.contains(chap.name)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable {
                                                    if (checked) {
                                                        viewModel.practiceSelectedTopics.remove(chap.name)
                                                    } else {
                                                        viewModel.practiceSelectedTopics.add(chap.name)
                                                    }
                                                }
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                                    .border(1.dp, if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f), RoundedCornerShape(4.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (checked) {
                                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(chap.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                                Text("Class ${chap.classNum} • ${chap.subject}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Question Count Selector Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "4. Number of Questions",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(3, 5, 10, 15, 20).forEach { num ->
                                val isSelected = viewModel.practiceQuestionCount == num
                                Button(
                                    onClick = { viewModel.practiceQuestionCount = num },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("$num Q", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Question Category Selector Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "5. Question Category",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("AI-Generated", "PYQ Main", "PYQ Advance").forEach { type ->
                                val isSelected = viewModel.questionType == type
                                Button(
                                    onClick = { viewModel.questionType = type },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(type, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }

            // Launch Practice Button
            item {
                val canLaunch = viewModel.practiceSelectedTopics.isNotEmpty()
                Button(
                    onClick = { viewModel.startPracticeSession() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("launch_practice_suite_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    enabled = canLaunch
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Launch custom practice test", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    } else {
        // Active Practice Session Mode
        if (viewModel.isPracticeLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Text("Aero Coach is preparing custom questions...", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    Text("Selecting optimized math and problem types.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                }
            }
        } else if (viewModel.practiceQuestions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                    Text("API Call Failed to Generate Questions", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Please verify your API key is correctly entered in settings, and try again shortly.", textAlign = TextAlign.Center, fontSize = 13.sp)
                    Button(onClick = { viewModel.endPracticeSession() }) {
                        Text("Exit Test")
                    }
                }
            }
        } else {
            val qIndex = viewModel.currentPracticeIndex
            val q = viewModel.practiceQuestions.getOrNull(qIndex)
            val totalQ = viewModel.practiceQuestions.size

            if (q != null) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Status Info
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Question ${qIndex + 1} of $totalQ",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f))
                            ) {
                                Text(
                                    text = "Score: ${viewModel.practiceScore} / $totalQ",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }

                    // Question Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = q.question,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    lineHeight = 22.sp
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                val optionsMap = listOf("A", "B", "C", "D")
                                val chosenAnswer: String? = viewModel.practiceUserAnswers[qIndex]
                                val showExplanation: Boolean = viewModel.practiceShowExplanations[qIndex] == true

                                q.options.forEachIndexed { optIdx, optionText ->
                                    val optionLetter = optionsMap.getOrNull(optIdx) ?: "A"
                                    val isSelected = chosenAnswer == optionLetter
                                    val isCorrect = q.correctOption == optionLetter

                                    val borderStroke = if (showExplanation) {
                                        if (isCorrect) BorderStroke(2.dp, Color(0xFF10B981))
                                        else if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.error)
                                        else null
                                    } else {
                                        if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.secondary) else null
                                    }

                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clickable {
                                                if (!showExplanation) {
                                                    viewModel.submitPracticeAnswer(qIndex, optionLetter)
                                                }
                                            },
                                        border = borderStroke,
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f)
                                            else MaterialTheme.colorScheme.background
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.secondary
                                                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    optionLetter,
                                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(optionText, fontSize = 14.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Detailed Proof/Derivation Card
                    val showExplanation: Boolean = viewModel.practiceShowExplanations[qIndex] == true
                    if (showExplanation) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.05f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Aero Complete Proof & Solution",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = q.solution,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    // Bottom Navigation Controls
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { viewModel.prevPracticeQuestion() },
                                enabled = qIndex > 0,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                            ) {
                                Text("Previous")
                            }

                            if (qIndex < totalQ - 1) {
                                Button(
                                    onClick = { viewModel.nextPracticeQuestion() },
                                    enabled = showExplanation
                                ) {
                                    Text("Next Question")
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.endPracticeSession() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("Finish & Exit Test")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== 4. DOUBT SOLVER SCREEN ====================
@Composable
fun DoubtSolverScreen(viewModel: JeeViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            viewModel.doubtImageBitmap = bitmap
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "Camera permission is required to take photos of textbook questions.", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "JEE Doubt Desk",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Input doubt area
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Enter query or paste problem text",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = viewModel.doubtInput,
                        onValueChange = { viewModel.doubtInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("doubt_input_field"),
                        placeholder = { Text("e.g. Find the magnetic field at the center of a circular current carrying loop...", fontSize = 13.sp) },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Image upload / Camera capture for JEE textbook questions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Include Problem Image?", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (viewModel.doubtImageBitmap == null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                    if (hasPermission) {
                                        cameraLauncher.launch(null)
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("camera_photo_btn")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text("Take Photo", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }

                            Button(
                                onClick = {
                                    // Simulated upload - create placeholder diagram representing a JEE mechanics diagram
                                    val dummyBitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
                                    viewModel.doubtImageBitmap = dummyBitmap
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("mock_image_btn")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                                    Text("Mock Diagram", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Image(
                                    bitmap = viewModel.doubtImageBitmap!!.asImageBitmap(),
                                    contentDescription = "Textbook Question Photo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                ) {
                                    IconButton(
                                        onClick = { viewModel.clearDoubtImage() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Remove Photo", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(6.dp)
                                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Image Ready", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.solveDoubt() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("solve_doubt_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Explain Step-by-Step", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Response
        if (viewModel.isDoubtLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else if (viewModel.doubtResponse.isNotEmpty()) {
            item {
                if (viewModel.isDoubt429Error) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Warning Rate Limit",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Rate Limit Exceeded (Code 429)",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Aero Coach is currently processing too many requests, or the shared free-tier Gemini API quota is fully exhausted.\n\n" +
                                        "💡 How to Proceed:\n" +
                                        "1. Wait 60 seconds and click 'Explain Step-by-Step' again.\n" +
                                        "2. Enter your own custom GEMINI_API_KEY inside the 'Config Settings' tab to bypass the public quota limit completely.",
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Aero Deep Explanation",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                IconButton(onClick = { viewModel.speakText(viewModel.doubtResponse) }) {
                                    Icon(
                                        if (viewModel.isSpeechPlaying) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                        contentDescription = "TTS",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = viewModel.doubtResponse,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==================== 5. FOCUS SCREEN ====================
@Composable
fun FocusScreen(viewModel: JeeViewModel) {
    val mins = viewModel.focusSecondsRemaining / 60
    val secs = viewModel.focusSecondsRemaining % 60
    val progressRatio = viewModel.focusSecondsRemaining.toFloat() / (viewModel.focusTimeMins * 60).toFloat()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "JEE Immersive Focus Zone",
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Block distracting apps and stay locked in",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Glowing Circle Timer
        Box(
            modifier = Modifier
                .size(220.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .border(6.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Glowing neon arc simulation
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = String.format("%02d:%02d", mins, secs),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "TARGET TIME",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Timer Adjusters (Only if timer is stopped)
        if (!viewModel.isFocusTimerRunning) {
            Row(
                modifier = Modifier.padding(bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                IconButton(onClick = {
                    if (viewModel.focusTimeMins > 5) {
                        viewModel.focusTimeMins -= 5
                        viewModel.focusSecondsRemaining = viewModel.focusTimeMins * 60
                    }
                }) {
                    Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", modifier = Modifier.size(32.dp))
                }
                Text("${viewModel.focusTimeMins} minutes", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = {
                    if (viewModel.focusTimeMins < 180) {
                        viewModel.focusTimeMins += 5
                        viewModel.focusSecondsRemaining = viewModel.focusTimeMins * 60
                    }
                }) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", modifier = Modifier.size(32.dp))
                }
            }
        }

        // Control Buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(bottom = 24.dp)
        ) {
            if (!viewModel.isFocusTimerRunning) {
                Button(
                    onClick = { viewModel.startFocusSession() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("start_focus_btn")
                ) {
                    Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Session", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Button(
                    onClick = { viewModel.pauseFocusSession() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("pause_focus_btn")
                ) {
                    Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Default.Pause, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pause", fontWeight = FontWeight.Bold)
                    }
                }
                Button(
                    onClick = { viewModel.stopFocusSession() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Study Music & Lyria Sound track (Generate track)
        Text("Study Sounds & Binaural Music", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val tracks = listOf("Orchestral Focus", "Alpha Waves", "Rain")
            tracks.forEach { track ->
                val active = viewModel.activeAmbientTrack == track
                Button(
                    onClick = {
                        viewModel.activeAmbientTrack = if (active) "None" else track
                        if (viewModel.activeAmbientTrack != "None") {
                            viewModel.speakText("Playing $track study enhancement audio loop.")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (active) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                ) {
                    Text(
                        track,
                        fontSize = 11.sp,
                        color = if (active) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ==================== 6. AERO CHAT SCREEN ====================
@Composable
fun AeroChatScreen(viewModel: JeeViewModel) {
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Aero Coach banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Aero: Your AI Coach", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Supercharged guidance tailored for Allen students.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                }
            }
        }

        // Messages Thread
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (viewModel.chatMessages.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Hi Jeet! I'm Aero. Ask me for study strategies, module solving tricks, or schedule tips.",
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 32.dp),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            } else {
                items(viewModel.chatMessages) { msg ->
                    ChatBubble(msg)
                }
            }

            if (viewModel.isChatLoading) {
                item {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Aero is generating feedback...", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            if (viewModel.isChat429Error) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Warning Rate Limit",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Rate Limit Exceeded (Code 429)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Aero Coach is currently processing too many requests. Please wait 60 seconds, or configure a custom API key in the Config Settings tab.",
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Message input bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = viewModel.chatInput,
                onValueChange = { viewModel.chatInput = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                placeholder = { Text("Ask Aero...", fontSize = 14.sp) },
                shape = RoundedCornerShape(24.dp)
            )
            IconButton(
                onClick = { viewModel.sendChatMessage() },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .testTag("chat_send_btn")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val align = if (msg.isUser) Alignment.End else Alignment.Start
    val containerCol = if (msg.isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val textCol = if (msg.isUser) Color.White else MaterialTheme.colorScheme.onSurface

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = align
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (msg.isUser) 16.dp else 4.dp,
                bottomEnd = if (msg.isUser) 4.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(containerColor = containerCol),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Text(
                text = msg.text,
                modifier = Modifier.padding(12.dp),
                fontSize = 14.sp,
                color = textCol
            )
        }
    }
}

// ==================== 7. VISUAL CONCEPT LAB SCREEN ====================
@Composable
fun VisualLabScreen(viewModel: JeeViewModel) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "AI Visual Concept Lab",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Generate rigorous, high-fidelity images of physical/chemical setups & animate with Veo",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Design Concept Setup Prompt",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = viewModel.visualizerPrompt,
                        onValueChange = { viewModel.visualizerPrompt = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .testTag("lab_prompt_field"),
                        placeholder = { Text("e.g. Total Internal Reflection inside a semi-circular glass prism...", fontSize = 13.sp) },
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.generateVisualizerConcept() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_image_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Image, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate Diagram (1K/2K)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Image Output
        if (viewModel.isVisualizerLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else {
            if (viewModel.isVisualizer429Error) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Warning Rate Limit",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Rate Limit Exceeded (Code 429)",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Aero Coach is currently processing too many requests, or the shared free-tier Gemini API quota is fully exhausted.\n\n" +
                                        "💡 How to Proceed:\n" +
                                        "1. Wait 60 seconds and try generating the concept diagram again.\n" +
                                        "2. Enter your own custom GEMINI_API_KEY inside the 'Config Settings' tab to bypass the public quota limit completely.",
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
            viewModel.visualizerImage?.let { img ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Image(
                                bitmap = img.asImageBitmap(),
                                contentDescription = "Generated JEE Concept",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            if (viewModel.generatedVideoUrl == null) {
                                Button(
                                    onClick = { viewModel.animateConceptToVideo() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("animate_video_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Movie, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Animate setup with Veo (16:9)", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Video Player simulation
        if (viewModel.isVideoGenerating) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Veo is animating mechanics physics frame...", fontSize = 13.sp)
                    }
                }
            }
        } else {
            viewModel.generatedVideoUrl?.let { video ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Veo Generated Concept Video", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(8.dp))
                            // simulated video frame
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                viewModel.visualizerImage?.let { img ->
                                    Image(
                                        bitmap = img.asImageBitmap(),
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop,
                                        alpha = 0.7f
                                    )
                                }
                                Icon(Icons.Default.PlayCircle, contentDescription = "Play", modifier = Modifier.size(64.dp), tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== 8. CONFIG / SETTINGS SCREEN ====================
@Composable
fun SettingsScreen(viewModel: JeeViewModel) {
    val tasks by viewModel.allTodoTasks.collectAsState()
    var newTaskText by remember { mutableStateOf("") }
    var taskSubject by remember { mutableStateOf("General") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Config & Daily Actions",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Theme & Notifications controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Preferences", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Dark Theme toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Dark theme", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Highly recommended for long study nights", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                        Switch(
                            checked = viewModel.isDarkTheme,
                            onCheckedChange = { viewModel.toggleTheme() },
                            modifier = Modifier.testTag("theme_toggle_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Grace Alerts Notifications toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Schedule grace alerts", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Remind me when I go out of schedule", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                        Switch(
                            checked = viewModel.isNotificationsEnabled,
                            onCheckedChange = { viewModel.isNotificationsEnabled = it },
                            modifier = Modifier.testTag("notif_toggle_switch")
                        )
                    }
                }
            }
        }

        // To-Do list header
        item {
            Text(
                text = "My JEE Task Manager (To-Do List)",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Add task inputs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Add New Study Task", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newTaskText,
                            onValueChange = { newTaskText = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("todo_input_field"),
                            placeholder = { Text("Complete chemical kinetics assignment...", fontSize = 13.sp) },
                            shape = RoundedCornerShape(10.dp)
                        )
                        IconButton(
                            onClick = {
                                viewModel.addTask(newTaskText, taskSubject)
                                newTaskText = ""
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary)
                                .testTag("add_todo_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Subject label row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val subs = listOf("General", "Physics", "Chemistry", "Maths")
                        subs.forEach { s ->
                            val isSelected = taskSubject == s
                            Button(
                                onClick = { taskSubject = s },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 2.dp)
                            ) {
                                Text(s, fontSize = 10.sp, color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }
        }

        // Tasks list
        if (tasks.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(top = 16.dp), contentAlignment = Alignment.Center) {
                    Text("No tasks added yet. Plan tomorrow's goals!", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            }
        } else {
            items(tasks) { task ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Checkbox(
                                checked = task.isCompleted,
                                onCheckedChange = { viewModel.toggleTask(task) },
                                modifier = Modifier.testTag("todo_checkbox_${task.id}")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = task.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textDecoration = if (task.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                                    color = if (task.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = task.subject,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        IconButton(onClick = { viewModel.deleteTask(task) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}
