package com.example.data

import android.util.Log
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class JeeRepository(private val jeeDao: JeeDao) {

    val allTopicProgress: Flow<List<TopicProgress>> = jeeDao.getAllTopicProgress()
    val allTodoTasks: Flow<List<TodoTask>> = jeeDao.getAllTodoTasks()
    val allSavedQuestions: Flow<List<SavedQuestion>> = jeeDao.getAllSavedQuestions()

    fun getTopicProgressBySubject(subject: String): Flow<List<TopicProgress>> {
        return jeeDao.getTopicProgressBySubject(subject)
    }

    fun getScheduleLogsForDate(dateStr: String): Flow<List<ScheduleLog>> {
        return jeeDao.getScheduleLogsForDate(dateStr)
    }

    suspend fun getScheduleLogForSlot(dateStr: String, slotId: String): ScheduleLog? = withContext(Dispatchers.IO) {
        jeeDao.getScheduleLogForSlot(dateStr, slotId)
    }

    suspend fun insertScheduleLog(log: ScheduleLog) = withContext(Dispatchers.IO) {
        jeeDao.insertScheduleLog(log)
        triggerScheduleSync()
    }

    suspend fun deleteScheduleLogForSlot(dateStr: String, slotId: String) = withContext(Dispatchers.IO) {
        jeeDao.deleteScheduleLogForSlot(dateStr, slotId)
        triggerScheduleSync()
    }

    suspend fun insertTopicProgress(progress: TopicProgress) = withContext(Dispatchers.IO) {
        jeeDao.insertTopicProgress(progress)
        triggerTopicSync()
    }

    suspend fun updateTopicProgress(progress: TopicProgress) = withContext(Dispatchers.IO) {
        jeeDao.updateTopicProgress(progress)
        triggerTopicSync()
    }

    suspend fun insertTodoTask(task: TodoTask) = withContext(Dispatchers.IO) {
        jeeDao.insertTodoTask(task)
        triggerTodoSync()
    }

    suspend fun updateTodoTask(task: TodoTask) = withContext(Dispatchers.IO) {
        jeeDao.updateTodoTask(task)
        triggerTodoSync()
    }

    suspend fun deleteTodoTask(task: TodoTask) = withContext(Dispatchers.IO) {
        jeeDao.deleteTodoTask(task)
        triggerTodoSync()
    }

    private suspend fun triggerScheduleSync() {
        try {
            val list = jeeDao.getAllScheduleLogsList()
            com.example.network.CloudSyncManager.pushScheduleLogs(list)
        } catch (e: Exception) {
            Log.e("JeeRepository", "Error triggering schedule sync", e)
        }
    }

    private suspend fun triggerTopicSync() {
        try {
            val list = jeeDao.getAllTopicProgressList()
            com.example.network.CloudSyncManager.pushTopicProgress(list)
        } catch (e: Exception) {
            Log.e("JeeRepository", "Error triggering topic sync", e)
        }
    }

    private suspend fun triggerTodoSync() {
        try {
            val list = jeeDao.getAllTodoTasksList()
            com.example.network.CloudSyncManager.pushTodoTasks(list)
        } catch (e: Exception) {
            Log.e("JeeRepository", "Error triggering todo sync", e)
        }
    }

    suspend fun getQuestionsByFilter(subject: String, topic: String, type: String): List<SavedQuestion> = withContext(Dispatchers.IO) {
        jeeDao.getQuestionsByFilter(subject, topic, type)
    }

    suspend fun insertSavedQuestion(question: SavedQuestion) = withContext(Dispatchers.IO) {
        jeeDao.insertSavedQuestion(question)
    }

    suspend fun updateSavedQuestion(question: SavedQuestion) = withContext(Dispatchers.IO) {
        jeeDao.updateSavedQuestion(question)
    }

    suspend fun prepopulateTopicsIfNeeded() = withContext(Dispatchers.IO) {
        val count = jeeDao.getTopicCount()
        if (count < 50) {
            jeeDao.deleteAllTopicProgress()
            val topics = ALL_JEE_CHAPTERS.map { chapter ->
                TopicProgress(
                    subject = chapter.subject,
                    topicName = chapter.name
                )
            }
            jeeDao.insertTopicProgressList(topics)
        }
    }

    suspend fun performCloudSync() = withContext(Dispatchers.IO) {
        val syncResult = com.example.network.CloudSyncManager.syncAllFromCloud(jeeDao)
        prepopulateTopicsIfNeeded()
        if (syncResult) {
            Log.d("JeeRepository", "Initial cloud sync successfully completed!")
        } else {
            // First run or offline, push local topics up if we have them
            triggerTopicSync()
        }
    }
}
