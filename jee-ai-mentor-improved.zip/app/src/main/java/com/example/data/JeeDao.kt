package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface JeeDao {

    // --- Topic Progress Queries ---
    @Query("SELECT * FROM topic_progress ORDER BY subject, topicName")
    fun getAllTopicProgress(): Flow<List<TopicProgress>>

    @Query("SELECT * FROM topic_progress ORDER BY subject, topicName")
    suspend fun getAllTopicProgressList(): List<TopicProgress>

    @Query("SELECT * FROM topic_progress WHERE subject = :subject ORDER BY topicName")
    fun getTopicProgressBySubject(subject: String): Flow<List<TopicProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopicProgress(progress: TopicProgress)

    @Update
    suspend fun updateTopicProgress(progress: TopicProgress)

    @Query("SELECT COUNT(*) FROM topic_progress")
    suspend fun getTopicCount(): Int

    @Query("DELETE FROM topic_progress")
    suspend fun deleteAllTopicProgress()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopicProgressList(list: List<TopicProgress>)


    // --- Todo Task Queries ---
    @Query("SELECT * FROM todo_task ORDER BY timestamp DESC")
    fun getAllTodoTasks(): Flow<List<TodoTask>>

    @Query("SELECT * FROM todo_task ORDER BY timestamp DESC")
    suspend fun getAllTodoTasksList(): List<TodoTask>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodoTask(task: TodoTask)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodoTaskList(list: List<TodoTask>)

    @Update
    suspend fun updateTodoTask(task: TodoTask)

    @Delete
    suspend fun deleteTodoTask(task: TodoTask)

    @Query("DELETE FROM todo_task")
    suspend fun deleteAllTodoTasks()


    // --- Schedule Log Queries ---
    @Query("SELECT * FROM schedule_log")
    suspend fun getAllScheduleLogsList(): List<ScheduleLog>

    @Query("SELECT * FROM schedule_log WHERE dateStr = :dateStr")
    fun getScheduleLogsForDate(dateStr: String): Flow<List<ScheduleLog>>

    @Query("SELECT * FROM schedule_log WHERE dateStr = :dateStr AND slotId = :slotId LIMIT 1")
    suspend fun getScheduleLogForSlot(dateStr: String, slotId: String): ScheduleLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduleLog(log: ScheduleLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduleLogList(list: List<ScheduleLog>)

    @Query("DELETE FROM schedule_log WHERE dateStr = :dateStr AND slotId = :slotId")
    suspend fun deleteScheduleLogForSlot(dateStr: String, slotId: String)

    @Query("DELETE FROM schedule_log")
    suspend fun deleteAllScheduleLogs()


    // --- Saved Question Queries ---
    @Query("SELECT * FROM saved_question ORDER BY timestamp DESC")
    fun getAllSavedQuestions(): Flow<List<SavedQuestion>>

    @Query("SELECT * FROM saved_question WHERE subject = :subject AND topic = :topic AND questionType = :type")
    suspend fun getQuestionsByFilter(subject: String, topic: String, type: String): List<SavedQuestion>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedQuestion(question: SavedQuestion)

    @Update
    suspend fun updateSavedQuestion(question: SavedQuestion)
}
