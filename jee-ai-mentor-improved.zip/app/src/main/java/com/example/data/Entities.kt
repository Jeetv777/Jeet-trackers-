package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "topic_progress")
data class TopicProgress(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String, // "Physics", "Chemistry", "Maths"
    val topicName: String,
    val done: Boolean = false,
    val revised: Boolean = false,
    val complete: Boolean = false,
    val understood: Boolean = false
)

@Entity(tableName = "todo_task")
data class TodoTask(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val isCompleted: Boolean = false,
    val subject: String = "General", // "Physics", "Chemistry", "Maths", "General"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "schedule_log")
data class ScheduleLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateStr: String, // "YYYY-MM-DD" in Indian standard time
    val slotId: String,
    val checkedInTime: Long,
    val status: String // "CheckedIn", "GraceExpired", "Missed"
)

@Entity(tableName = "saved_question")
data class SavedQuestion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val topic: String,
    val questionType: String, // "PYQ Main", "PYQ Advance", "AI-Generated"
    val questionText: String,
    val options: String, // Pipe-separated options: "A | B | C | D"
    val correctOption: String, // "A", "B", "C", "D"
    val solutionText: String,
    val userAnswer: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class JeeChapter(val name: String, val classNum: Int, val subject: String)

val ALL_JEE_CHAPTERS = listOf(
    // --- Physics ---
    JeeChapter("Units and Measurements", 11, "Physics"),
    JeeChapter("Motion in a Straight Line", 11, "Physics"),
    JeeChapter("Motion in a Plane (Projectiles)", 11, "Physics"),
    JeeChapter("Laws of Motion (NLM)", 11, "Physics"),
    JeeChapter("Work, Energy and Power", 11, "Physics"),
    JeeChapter("System of Particles & Rotational Motion", 11, "Physics"),
    JeeChapter("Gravitation", 11, "Physics"),
    JeeChapter("Mechanical Properties of Solids", 11, "Physics"),
    JeeChapter("Mechanical Properties of Fluids", 11, "Physics"),
    JeeChapter("Thermal Properties of Matter", 11, "Physics"),
    JeeChapter("Thermodynamics", 11, "Physics"),
    JeeChapter("Kinetic Theory of Gases", 11, "Physics"),
    JeeChapter("Oscillations (SHM)", 11, "Physics"),
    JeeChapter("Waves & Sound", 11, "Physics"),
    JeeChapter("Electrostatics (Charges & Fields)", 12, "Physics"),
    JeeChapter("Electrostatic Potential & Capacitance", 12, "Physics"),
    JeeChapter("Current Electricity", 12, "Physics"),
    JeeChapter("Moving Charges and Magnetism", 12, "Physics"),
    JeeChapter("Magnetism and Matter", 12, "Physics"),
    JeeChapter("Electromagnetic Induction (EMI)", 12, "Physics"),
    JeeChapter("Alternating Current (AC)", 12, "Physics"),
    JeeChapter("Electromagnetic Waves", 12, "Physics"),
    JeeChapter("Ray Optics & Optical Instruments", 12, "Physics"),
    JeeChapter("Wave Optics", 12, "Physics"),
    JeeChapter("Dual Nature of Radiation & Matter", 12, "Physics"),
    JeeChapter("Atoms and Nuclei", 12, "Physics"),
    JeeChapter("Semiconductor Electronics", 12, "Physics"),

    // --- Chemistry ---
    JeeChapter("Some Basic Concepts (Mole)", 11, "Chemistry"),
    JeeChapter("Structure of Atom", 11, "Chemistry"),
    JeeChapter("Classification & Periodicity", 11, "Chemistry"),
    JeeChapter("Chemical Bonding & Molecular Structure", 11, "Chemistry"),
    JeeChapter("Chemical Thermodynamics", 11, "Chemistry"),
    JeeChapter("Chemical & Ionic Equilibrium", 11, "Chemistry"),
    JeeChapter("Redox Reactions", 11, "Chemistry"),
    JeeChapter("General Organic Chemistry (GOC)", 11, "Chemistry"),
    JeeChapter("Hydrocarbons", 11, "Chemistry"),
    JeeChapter("Solutions", 12, "Chemistry"),
    JeeChapter("Electrochemistry", 12, "Chemistry"),
    JeeChapter("Chemical Kinetics", 12, "Chemistry"),
    JeeChapter("d- and f- Block Elements", 12, "Chemistry"),
    JeeChapter("Coordination Compounds", 12, "Chemistry"),
    JeeChapter("Haloalkanes and Haloarenes", 12, "Chemistry"),
    JeeChapter("Alcohols, Phenols and Ethers", 12, "Chemistry"),
    JeeChapter("Aldehydes, Ketones & Carboxylic Acids", 12, "Chemistry"),
    JeeChapter("Amines (Organic Nitrogen)", 12, "Chemistry"),
    JeeChapter("Biomolecules & Polymers", 12, "Chemistry"),

    // --- Maths ---
    JeeChapter("Sets, Relations and Functions", 11, "Maths"),
    JeeChapter("Trigonometric Functions", 11, "Maths"),
    JeeChapter("Complex Numbers & Quadratics", 11, "Maths"),
    JeeChapter("Linear Inequalities", 11, "Maths"),
    JeeChapter("Permutations and Combinations", 11, "Maths"),
    JeeChapter("Binomial Theorem", 11, "Maths"),
    JeeChapter("Sequence and Series (AP/GP)", 11, "Maths"),
    JeeChapter("Straight Lines", 11, "Maths"),
    JeeChapter("Conic Sections (Circle & Conics)", 11, "Maths"),
    JeeChapter("3D Geometry (Class 11 Intro)", 11, "Maths"),
    JeeChapter("Limits and Derivatives", 11, "Maths"),
    JeeChapter("Mathematical Reasoning", 11, "Maths"),
    JeeChapter("Statistics & Probability (Class 11)", 11, "Maths"),
    JeeChapter("Relations and Functions (Class 12)", 12, "Maths"),
    JeeChapter("Inverse Trigonometric Functions", 12, "Maths"),
    JeeChapter("Matrices & Determinants", 12, "Maths"),
    JeeChapter("Continuity and Differentiability", 12, "Maths"),
    JeeChapter("Application of Derivatives (AOD)", 12, "Maths"),
    JeeChapter("Integrals (Definite & Indefinite)", 12, "Maths"),
    JeeChapter("Application of Integrals (Area)", 12, "Maths"),
    JeeChapter("Differential Equations", 12, "Maths"),
    JeeChapter("Vector Algebra", 12, "Maths"),
    JeeChapter("Three Dimensional Geometry (3D Space)", 12, "Maths"),
    JeeChapter("Linear Programming", 12, "Maths"),
    JeeChapter("Probability (Class 12)", 12, "Maths")
)
