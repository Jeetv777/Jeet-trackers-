package com.example.network

import android.util.Log
import com.example.data.JeeDao
import com.example.data.SavedQuestion
import com.example.data.ScheduleLog
import com.example.data.TodoTask
import com.example.data.TopicProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object CloudSyncManager {
    private const val TAG = "CloudSyncManager"
    private const val BASE_URL = "https://jee-companion-shared-default-rtdb.firebaseio.com/jeet_data"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val mediaTypeJson = "application/json; charset=utf-8".toMediaType()

    private fun parseObjectsList(body: String): List<JSONObject> {
        val list = mutableListOf<JSONObject>()
        val trimmed = body.trim()
        try {
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    if (!arr.isNull(i)) {
                        list.add(arr.getJSONObject(i))
                    }
                }
            } else if (trimmed.startsWith("{")) {
                val obj = JSONObject(trimmed)
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val item = obj.optJSONObject(key)
                    if (item != null) {
                        list.add(item)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing JSON list helper", e)
        }
        return list
    }

    suspend fun syncAllFromCloud(jeeDao: JeeDao): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Starting full cloud sync...")

            // 1. Sync Topic Progress
            val topicUrl = "$BASE_URL/topic_progress.json"
            val topicRequest = Request.Builder().url(topicUrl).get().build()
            client.newCall(topicRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty() && body != "null") {
                        val items = parseObjectsList(body)
                        val cloudList = mutableListOf<TopicProgress>()
                        for (obj in items) {
                            cloudList.add(
                                TopicProgress(
                                    id = obj.optInt("id", 0),
                                    subject = obj.optString("subject", ""),
                                    topicName = obj.optString("topicName", ""),
                                    done = obj.optBoolean("done", false),
                                    revised = obj.optBoolean("revised", false),
                                    complete = obj.optBoolean("complete", false),
                                    understood = obj.optBoolean("understood", false)
                                )
                            )
                        }
                        if (cloudList.isNotEmpty()) {
                            jeeDao.deleteAllTopicProgress()
                            jeeDao.insertTopicProgressList(cloudList)
                            Log.d(TAG, "Synced ${cloudList.size} topics progress from cloud.")
                        }
                    }
                }
            }

            // 2. Sync Todo Tasks
            val todoUrl = "$BASE_URL/todo_task.json"
            val todoRequest = Request.Builder().url(todoUrl).get().build()
            client.newCall(todoRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty() && body != "null") {
                        val items = parseObjectsList(body)
                        val cloudList = mutableListOf<TodoTask>()
                        for (obj in items) {
                            cloudList.add(
                                TodoTask(
                                    id = obj.optInt("id", 0),
                                    title = obj.optString("title", ""),
                                    isCompleted = obj.optBoolean("isCompleted", false),
                                    subject = obj.optString("subject", "General"),
                                    timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                                )
                            )
                        }
                        if (cloudList.isNotEmpty()) {
                            jeeDao.deleteAllTodoTasks()
                            jeeDao.insertTodoTaskList(cloudList)
                            Log.d(TAG, "Synced ${cloudList.size} todo tasks from cloud.")
                        }
                    }
                }
            }

            // 3. Sync Schedule Logs
            val logUrl = "$BASE_URL/schedule_log.json"
            val logRequest = Request.Builder().url(logUrl).get().build()
            client.newCall(logRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty() && body != "null") {
                        val items = parseObjectsList(body)
                        val cloudList = mutableListOf<ScheduleLog>()
                        for (obj in items) {
                            cloudList.add(
                                ScheduleLog(
                                    id = obj.optInt("id", 0),
                                    dateStr = obj.optString("dateStr", ""),
                                    slotId = obj.optString("slotId", ""),
                                    checkedInTime = obj.optLong("checkedInTime", 0),
                                    status = obj.optString("status", "")
                                )
                            )
                        }
                        if (cloudList.isNotEmpty()) {
                            jeeDao.deleteAllScheduleLogs()
                            jeeDao.insertScheduleLogList(cloudList)
                            Log.d(TAG, "Synced ${cloudList.size} schedule logs from cloud.")
                        }
                    }
                }
            }

            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing from cloud", e)
            return@withContext false
        }
    }

    suspend fun pushTopicProgress(list: List<TopicProgress>) = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/topic_progress.json"
            val jsonArray = JSONArray()
            for (item in list) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("subject", item.subject)
                obj.put("topicName", item.topicName)
                obj.put("done", item.done)
                obj.put("revised", item.revised)
                obj.put("complete", item.complete)
                obj.put("understood", item.understood)
                jsonArray.put(obj)
            }
            val body = jsonArray.toString().toRequestBody(mediaTypeJson)
            val request = Request.Builder().url(url).put(body).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Failed to push topic progress: ${response.code}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pushing topic progress", e)
        }
    }

    suspend fun pushTodoTasks(list: List<TodoTask>) = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/todo_task.json"
            val jsonArray = JSONArray()
            for (item in list) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("title", item.title)
                obj.put("isCompleted", item.isCompleted)
                obj.put("subject", item.subject)
                obj.put("timestamp", item.timestamp)
                jsonArray.put(obj)
            }
            val body = jsonArray.toString().toRequestBody(mediaTypeJson)
            val request = Request.Builder().url(url).put(body).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Failed to push todo tasks: ${response.code}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pushing todo tasks", e)
        }
    }

    suspend fun pushScheduleLogs(list: List<ScheduleLog>) = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/schedule_log.json"
            val jsonArray = JSONArray()
            for (item in list) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("dateStr", item.dateStr)
                obj.put("slotId", item.slotId)
                obj.put("checkedInTime", item.checkedInTime)
                obj.put("status", item.status)
                jsonArray.put(obj)
            }
            val body = jsonArray.toString().toRequestBody(mediaTypeJson)
            val request = Request.Builder().url(url).put(body).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Failed to push schedule logs: ${response.code}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pushing schedule logs", e)
        }
    }
}
