package com.example.network

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Thin wrapper around the Gemini REST API (generateContent).
 * All network calls run on Dispatchers.IO and never throw out of this object;
 * failures are surfaced as readable strings / null so the UI can show a message
 * instead of crashing.
 */
object GeminiService {
    private const val TAG = "GeminiService"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    private const val DEFAULT_MODEL = "models/gemini-3.5-flash"
    private const val JSON_MEDIA_TYPE = "application/json; charset=utf-8"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String = BuildConfig.GEMINI_API_KEY

    /**
     * Low-level call to POST {model}:generateContent with an arbitrary `contents` array.
     * Returns the raw JSON response body on success, or a failure Result with a
     * human-readable message.
     */
    private fun callGenerateContent(
        contents: JSONArray,
        systemInstruction: String?,
        model: String,
        jsonOutput: Boolean = false
    ): Result<JSONObject> {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return Result.failure(IllegalStateException("Missing GEMINI_API_KEY. Add it to your .env file and rebuild."))
        }

        val body = JSONObject().apply {
            put("contents", contents)
            if (!systemInstruction.isNullOrBlank()) {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            }
            if (jsonOutput) {
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                })
            }
        }

        val url = "$BASE_URL/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody(JSON_MEDIA_TYPE.toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val reason = parseErrorMessage(bodyStr) ?: "HTTP ${response.code}"
                    Log.e(TAG, "generateContent failed: ${response.code} $bodyStr")
                    Result.failure(IOException(reason))
                } else {
                    Result.success(JSONObject(bodyStr))
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error calling Gemini", e)
            Result.failure(IOException("Network error: ${e.message ?: "couldn't reach Gemini. Check your connection."}"))
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error calling Gemini", e)
            Result.failure(e)
        }
    }

    private fun parseErrorMessage(body: String): String? {
        return try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
    }

    /** Pulls the first candidate's text out of a generateContent response. */
    private fun extractText(response: JSONObject): String? {
        val candidates = response.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val parts = candidates.getJSONObject(0)
            .optJSONObject("content")
            ?.optJSONArray("parts") ?: return null
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().trim().ifBlank { null }
    }

    /** Strips ```json ... ``` fences some models still wrap around structured output. */
    private fun stripJsonFences(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.substringAfter("\n").substringBeforeLast("```")
        }
        return s.trim()
    }

    private fun bitmapToBase64Jpeg(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * General text generation. Uses [DEFAULT_MODEL] (Gemini 3.5 Flash) unless overridden.
     * Set [isThinkingHigh] for problems that benefit from deeper step-by-step reasoning
     * (e.g. multi-step JEE Advanced numericals). Currently reserved for future use.
     */
    suspend fun generateText(
        prompt: String,
        systemInstruction: String? = null,
        model: String = DEFAULT_MODEL,
        isThinkingHigh: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        val contents = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }
        )
        val result = callGenerateContent(contents, systemInstruction, model)
        result.fold(
            onSuccess = { extractText(it) ?: "Gemini returned an empty response. Please try again." },
            onFailure = { "Couldn't reach Gemini: ${it.message}" }
        )
    }

    /**
     * Multi-turn text generation. [history] alternates user/model turns (oldest first);
     * [prompt] is appended as the latest user turn.
     */
    suspend fun generateChatReply(
        history: List<Pair<String, Boolean>>, // text to isUser
        prompt: String,
        systemInstruction: String? = null,
        model: String = DEFAULT_MODEL
    ): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        for ((text, isUser) in history) {
            contents.put(JSONObject().apply {
                put("role", if (isUser) "user" else "model")
                put("parts", JSONArray().put(JSONObject().put("text", text)))
            })
        }
        contents.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", prompt)))
        })
        val result = callGenerateContent(contents, systemInstruction, model)
        result.fold(
            onSuccess = { extractText(it) ?: "Gemini returned an empty response. Please try again." },
            onFailure = { "Couldn't reach Gemini: ${it.message}" }
        )
    }

    /**
     * Multimodal text generation with an optional image input (e.g. a photo of a doubt/question).
     */
    suspend fun generateTextWithImage(
        prompt: String,
        imageBitmap: Bitmap?,
        systemInstruction: String? = null,
        model: String = DEFAULT_MODEL
    ): String = withContext(Dispatchers.IO) {
        val parts = JSONArray()
        if (imageBitmap != null) {
            parts.put(JSONObject().apply {
                put("inlineData", JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", bitmapToBase64Jpeg(imageBitmap))
                })
            })
        }
        parts.put(JSONObject().put("text", prompt))

        val contents = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", parts)
            }
        )
        val result = callGenerateContent(contents, systemInstruction, model)
        result.fold(
            onSuccess = { extractText(it) ?: "Gemini returned an empty response. Please try again." },
            onFailure = { "Couldn't reach Gemini: ${it.message}" }
        )
    }

    private const val QUESTION_JSON_SCHEMA = """
        Respond with ONLY a single JSON object (no markdown, no commentary) shaped exactly like:
        {"question": "...", "options": ["...", "...", "...", "..."], "correctOption": "A", "solution": "..."}
        Rules:
        - "options" must have exactly 4 entries, in order for A, B, C, D (do not prefix them with "A)" etc).
        - "correctOption" must be one of "A", "B", "C", "D".
        - "solution" should be a clear, step-by-step explanation suitable for a JEE Advanced aspirant.
    """

    /**
     * Generates a single topic-specific JEE question as structured JSON.
     */
    suspend fun generateJeeQuestion(
        subject: String,
        topic: String,
        type: String // "PYQ Main", "PYQ Advance", "AI-Generated"
    ): JSONObject? = withContext(Dispatchers.IO) {
        val prompt = """
            Create one $type multiple-choice question for JEE Advanced/Main level $subject,
            specifically on the topic "$topic". $QUESTION_JSON_SCHEMA
        """.trimIndent()

        val contents = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }
        )
        val result = callGenerateContent(contents, systemInstruction = null, model = DEFAULT_MODEL, jsonOutput = true)
        result.fold(
            onSuccess = { response ->
                val raw = extractText(response)
                if (raw == null) {
                    buildErrorQuestionJson("Gemini returned an empty response. Please try again.")
                } else {
                    try {
                        JSONObject(stripJsonFences(raw))
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to parse question JSON: $raw", e)
                        buildErrorQuestionJson("Couldn't parse Gemini's response. Please try again.")
                    }
                }
            },
            onFailure = { buildErrorQuestionJson(it.message ?: "Unknown error") }
        )
    }

    private fun buildErrorQuestionJson(message: String): JSONObject = JSONObject().apply {
        put("question", "Couldn't generate a question: $message")
        put("options", JSONArray().put("Retry").put("Check network").put("Check API key").put("Try later"))
        put("correctOption", "A")
        put("solution", "This is a fallback message, not a real question — please try again.")
    }

    /**
     * Generates multiple topic-specific JEE questions in one call as a structured JSON array.
     */
    suspend fun generateMultipleJeeQuestions(
        subject: String,
        topics: List<String>,
        count: Int,
        type: String // "PYQ Main", "PYQ Advance", "AI-Generated"
    ): List<com.example.viewmodel.JeeQuestionUi> = withContext(Dispatchers.IO) {
        val topicList = topics.joinToString(", ")
        val prompt = """
            Create $count distinct $type multiple-choice questions for JEE Advanced/Main level $subject,
            drawing from these topics: $topicList (spread the questions across the topics where possible).
            Respond with ONLY a JSON array (no markdown, no commentary) of $count objects, each shaped exactly like:
            {"question": "...", "options": ["...", "...", "...", "..."], "correctOption": "A", "solution": "..."}
            Rules:
            - "options" must have exactly 4 entries, in order for A, B, C, D (do not prefix them with "A)" etc).
            - "correctOption" must be one of "A", "B", "C", "D".
            - "solution" should be a clear, step-by-step explanation suitable for a JEE Advanced aspirant.
        """.trimIndent()

        val contents = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }
        )
        val result = callGenerateContent(contents, systemInstruction = null, model = DEFAULT_MODEL, jsonOutput = true)
        result.fold(
            onSuccess = { response ->
                val raw = extractText(response)
                if (raw == null) {
                    listOf(errorQuestionUi("Gemini returned an empty response. Please try again."))
                } else {
                    try {
                        val arr = JSONArray(stripJsonFences(raw))
                        val out = mutableListOf<com.example.viewmodel.JeeQuestionUi>()
                        for (i in 0 until arr.length()) {
                            val q = arr.getJSONObject(i)
                            val optArray = q.getJSONArray("options")
                            val options = (0 until optArray.length()).map { optArray.getString(it) }
                            out.add(
                                com.example.viewmodel.JeeQuestionUi(
                                    question = q.getString("question"),
                                    options = options,
                                    correctOption = q.getString("correctOption"),
                                    solution = q.getString("solution")
                                )
                            )
                        }
                        if (out.isEmpty()) listOf(errorQuestionUi("Gemini returned no questions. Please try again.")) else out
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to parse practice questions JSON: $raw", e)
                        listOf(errorQuestionUi("Couldn't parse Gemini's response. Please try again."))
                    }
                }
            },
            onFailure = { listOf(errorQuestionUi(it.message ?: "Unknown error")) }
        )
    }

    private fun errorQuestionUi(message: String) = com.example.viewmodel.JeeQuestionUi(
        question = "Couldn't generate a question: $message",
        options = listOf("Retry", "Check network", "Check API key", "Try later"),
        correctOption = "A",
        solution = "This is a fallback message, not a real question — please try again."
    )

    /**
     * Image generation for concept visualizations is not wired up yet (requires an
     * image-capable model such as gemini-3.1-flash-image and different response handling).
     * Returns null so callers can show a clear "not available" state instead of a fake image.
     */
    suspend fun generateConceptImage(
        prompt: String,
        aspectRatio: String = "1:1",
        imageSize: String = "1K"
    ): Bitmap? = withContext(Dispatchers.IO) {
        Log.w(TAG, "generateConceptImage is not implemented yet.")
        null
    }

    /**
     * TTS generation is not wired up yet; the app falls back to on-device Android TextToSpeech
     * (see JeeViewModel.speakText). Returns null so callers use that fallback.
     */
    suspend fun generateSpeechWithGemini(text: String): ByteArray? = withContext(Dispatchers.IO) {
        Log.w(TAG, "generateSpeechWithGemini is not implemented yet.")
        null
    }
}
