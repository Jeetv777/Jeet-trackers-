package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF0D9488)
val IndigoSecondary = Color(0xFF4F46E5)
val RoseTertiary = Color(0xFFF43F5E)

// IIT Golden Wings Theme Colors
val GoldAccent = Color(0xFFFFD700)
val DarkGold = Color(0xFFC5A059)
val CosmicGold = Color(0xFFEAB308)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF151D2F)
val DarkCard = Color(0xFF1E293B)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFE2E8F0)

